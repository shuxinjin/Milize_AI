# -*- coding: utf-8 -*-
'''
Name        : HtmlStripper.py
Purpose     : htmlファイルからbody情報抽出
Created Date: 2018.10.15
Created by  : Wenfeng Huang (MILIZE Inc.)
Updated Date: 2018.10.15
Updated by  : Wenfeng Huang (MILIZE Inc.)
'''

from html.parser import HTMLParser
import io


class HtmlStripper(HTMLParser):
    _flag = False

    def __init__(self, s):
        super().__init__()
        self._sio = io.StringIO()
        self.feed(s)

    def handle_starttag(self, tag, attrs):
        if tag == 'body':
            self._flag = True

    def handle_endtag(self, tag):
        if tag == 'body':
            self._flag = False

    def handle_data(self, data):
        if self._flag:
            self._sio.write(data)

    @property
    def value(self):
        return self._sio.getvalue()

