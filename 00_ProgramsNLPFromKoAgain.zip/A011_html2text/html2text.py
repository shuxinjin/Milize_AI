# -*- coding: utf-8 -*-
'''
Name        : html2text.py
Purpose     : htmlファイルからテキスト抽出
Created Date: 2018.12.20
Created by  : Wenfeng Huang (MILIZE Inc.)
Updated Date: 2018.12.20
Updated by  : Wenfeng Huang (MILIZE Inc.)
'''

import sys
sys.path.append('../A50_Config')
sys.path.append('../A90_utils')
import os  # noqa: E402
import re  # noqa: E402

from config_roll import file_names  # noqa: E402
from localIO import create_outdir  # noqa: E402
from m_txtm_base import m_txtm_base  # noqa: E402

from HtmlStripper import HtmlStripper  # noqa: E402


sub_patterns = [
                ['\A\n+', ''],  # 先頭の連続空行削除
                ['\n+', '\n'],  # 文中の連続空行削除
                ['\n+\Z', ''],  # 最後の連続空行削除
                ]


class html2text(m_txtm_base):

    _log_prefix = 'html2text_'
    _log_dir = '../../log/html'

    def main(self):
        def f_filter(x) : return x.endswith('.html')

        print(os.path.abspath(file_names.HTML_HOME_DIR))
        for root, _, files in os.walk(file_names.HTML_HOME_DIR):
            for f in list(filter(f_filter, files)):
                in_f = os.path.join(root, f)
                out_f = in_f.replace('.html', '.txt')
                out_f = out_f.replace(file_names.HTML_HOME_DIR,
                                      file_names.TEXT_HOME_DIR)
                create_outdir(out_f)

                self._log('Input: {}'.format(in_f))
                self._log('Output: {}'.format(out_f))
                with open(in_f,  mode='r', encoding='utf-8') as r, \
                        open(out_f, mode='w', encoding='utf-8') as o:

                    value = HtmlStripper(r.read()).value
                    for p in sub_patterns:
                        value = re.sub(p[0], p[1], value)
                    print(value, file=o)

if __name__ == '__main__':
    with html2text() as h2t:
        h2t.main()
