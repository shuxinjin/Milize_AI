#!/bin/bash

#Name        : PDF_txt_Converter.sh
#Purpose     : PDFファイルのテキスト変換
#Created Date: 2018.08.08
#Created by  : Wenfeng Huang (MILIZE Inc.)
#Updated Date: 2018.08.08
#Updated by  : Wenfeng Huang (MILIZE Inc.)

baseDir=`pwd`/../../01_TextMining_Files
# Folder structure:
# 01_TextMining_Files
#     01_Input
#           SMBC
#               *.pdf
#           SMBC_Credit
#               *.pdf
#           野村證券
#               *.pdf
#
#     02_Out_PDF_text
#           自動生成...

# 入力フォルダ
inDir=${baseDir}/01_Input/野村證券2
# 出力フォルダ
outDir=${baseDir}/02_Out_PDF_text/Nomura2

# ログ出力フォルダ
#logDir=$(cd $(dirname $0);pwd)/log
logDir=`pwd`/../../log/PDFConverter
if [ ! -d "${logDir}" ]; then
    mkdir -p "${logDir}"
fi

#現在日時
now=`date +'%Y%m%d_%H%M%S'`
#ログファイル
log_file=${logDir}/log_${now}.txt
#エラーファイル
err_file=${logDir}/err_${now}.txt

touch "${log_file}"
touch "${err_file}"

# 前回処理した後残った日時ファイルに基づき、ファイルの日付チェック
latest_time=`date -d "10 years ago" "+%Y-%m-01 00:00:00"`
#time_check_file=./time_check
#if [ ! -f $time_check_file ]; then
#    latest_time=`date -d "10 years ago" "+%Y-%m-01 00:00:00"`
#else
#    latest_time=`ls --full-time ${time_check_file} | awk '{print $6,$7;}'`
#fi

echo latest=${latest_time}

# 入力フォルダ（サブフォルダ含む）からファイル検出
# find $inDir -type f -name '*.pdf' | while read FILE; do
# ファイルの更新日時を比較して選出
find $inDir -type f -name '*.pdf' -newermt "${latest_time}" | while read FILE; do
          # フォルダ名取り除き
	 f_base_name=$(basename ${FILE})
          # 出力ファイル名のフルパス作成（拡張子pdfをtxtに変換も行う）
	 out_f=${outDir}/${f_base_name%.pdf}.html
          # テキスト変換の実行
          if [ ! -f "${out_f}" ]; then
              # そのままだと、フォルダがない場合はエラー発生
              #pdftotext "${FILE}" "${out_f}"
              # 変換の前に出力用のフォルダ存在かどうか確認
              if [ ! -d "${outDir}" ]; then
              # 出力フォルダ存在しない場合、作成しておく
                   mkdir -p "${outDir}"
              fi
              # 変換前に、変換対象ファイル名出力
              echo "Convert: ${FILE}" >> "${log_file}"
              echo "Convert: ${FILE}"
              pdf2htmlEX --process-outline 0 --dest-dir "${out_d}" --no-drm 1 --process-nontext 0 --printing 0 --optimize-text 1 "${FILE}" "${out_f}" || echo "${FILE}" >> "${err_file}"
          fi
done #&& touch ${time_check_file}

# update the time stamp
