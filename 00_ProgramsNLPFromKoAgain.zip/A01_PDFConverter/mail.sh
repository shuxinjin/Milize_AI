#!/bin/bash

#host=smtp.gmail.com
host=af108.secure.ne.jp
#port=465
port=587
user=wfhuang@afginc.co.jp
pass=qD8HVcGQhy
to=wfhuang@milize.co.jp
#from=wfhuang@milize.co.jp
from=wfhuang@afginc.co.jp

function mail_input {
  # echo "HELO localhost"
  echo "EHLO $host"
  sleep 1
  # echo "auth login"
  # echo "$user"
  # echo "$pass"
  echo "mail from: $from"
  echo "rcpt to: $to"
  echo "data"
  echo "To: $to"
  echo "From: $from"
  echo "Subject: Hello Mail Server"
  echo ""
  echo "test mail"
  echo "."
  echo "quit"
}

# send
mail_input | nc $host $port
# mail_input
