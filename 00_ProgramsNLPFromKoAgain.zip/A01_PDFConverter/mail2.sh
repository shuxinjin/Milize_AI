sendEmail -l email.log     \
    -f "wfhuang@afginc.co.jp"   \
    -u "テストです。"     \
    -t "wfhuang@afginc.co.jp" \
    -s "af108.secure.ne.jp:587"  \
    -o tls=auto \
    -xu "wfhuang@afginc.co.jp" \
    -xp "qD8HVcGQhy" \
    -o message-file="./mailbody.txt" \
    -o message-charset=utf-8
    #-m "message"
