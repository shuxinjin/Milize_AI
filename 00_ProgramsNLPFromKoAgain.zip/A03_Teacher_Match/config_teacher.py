# -*- coding: utf-8 -*-
'''
Name        : config_teacher.py
Version     : 2.0
Purpose     : 教師データ合わせ用の定数まとめ
Created Date: 2018.8.3
Created by  : Wenfeng Huang (MILIZE Inc.)
Updated Date: 2018.8.3
Updated by  : Wenfeng Huang (MILIZE Inc.)
'''

#
# To do
#
