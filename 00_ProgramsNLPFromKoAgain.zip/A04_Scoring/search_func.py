# -*- coding: utf-8 -*-
'''
Name        : search_func.py
Purpose     : 検索機能
Created Date: 2018.10.23
Created by  : Wenfeng Huang (Milize Inc.)
Updated Date: 2018.10.23
Updated by  : Wenfeng Huang (Milze Inc.)
'''

import sys
sys.path.append('../A50_Config')
sys.path.append('../A90_utils')

import os
import pandas            as     pd
import re

from   A50_Config.config_roll   import file_names
from   A90_utils.localIO        import create_outdir

from   .config_scoring          import col_names
from   .config_scoring          import brokers
from   .config_scoring          import file_names as local_files

def read_uniq_mapping():
    
    f = file_names.UNIQ_MAP_FILE
    col_key = '用語'
    col_val = '集約用語'
    col_skip = 'Skip'
    df = pd.read_csv(f, 
                     encoding = file_names.FILE_ENCODING, 
                     engine = 'python',
                     index_col = col_key,
                     usecols = [col_key, col_val, col_skip],
                     )
    df = df[pd.isnull(df[col_skip])]
    
    return df.to_dict()[col_val]

def read_pn_value():
    '''
    戻り値：
    Dataframe: index = '用語', columns = [集約用語, 加重平均極性値]
    '''
    f = file_names.UNIQ_MAP_FILE
    col_word      = '用語'
    col_uniq_word = '集約用語'
    col_pn_val    = '加重平均極性値'
    col_skip      = 'Skip'
    df = pd.read_csv(f, 
                     encoding = file_names.FILE_ENCODING, 
                     engine = 'python',
                     index_col = col_word,
                     usecols = [col_word, col_uniq_word, col_pn_val, col_skip],
                     dtype = {col_pn_val : float}
                     )
    df = df[pd.isnull(df[col_skip])]
    
    new_df = pd.DataFrame(df.groupby([col_uniq_word])[col_pn_val].mean(), columns = [col_pn_val])
#    df = df.drop(columns = [col_pn_val, col_skip])
#    
#    df = pd.merge(df, new_df, how = 'left', left_on = [col_uniq_word], right_index = True)
    
#    out_f = re.sub(r'\.csv$', '-revised.csv', f)
#    df.to_csv(out_f, encoding = file_names.FILE_ENCODING)
    
    return new_df.to_dict()[col_pn_val]

def create_report_pdf_table():
    
    p0 = re.compile(r'\\')
    p = re.compile(r'(?i)\.pdf$')
    d = file_names.PDF_DIR
    dic = {}
    for root, dirs, files in os.walk(d):
        for f in files:
            if p.search(f) is not None:
                report_id = p.sub('', f)
                pdf_path = p0.sub('/', os.path.join(root, f))
                dic[report_id] = pdf_path
    df = pd.DataFrame.from_dict(dic, orient = 'index', columns = [col_names.PDF_PATH])
    df.index.name = col_names.REPORT_ID
    out_f = file_names.REPORT_PDF_FILE
    create_outdir(out_f)
    df.to_csv(out_f, encoding = file_names.FILE_ENCODING)
    
def read_word_item_table(sec_code : str):
    
    item_f = file_names.WORD_COUNT_ITEM
    df_item = pd.read_csv(item_f, 
                          encoding = file_names.FILE_ENCODING,
                          engine = 'python',
                          dtype = {col_names.SEC_CODE : str, col_names.BROKER_ID : str}
                          )
    
    return df_item[df_item[col_names.SEC_CODE] == sec_code].drop(columns = [col_names.FULL_PATH])

def read_doc_word_table(feature_word):
    
    doc_word_f = file_names.DOC_WORD_FILE
    df_doc_word = pd.read_csv(doc_word_f, encoding = file_names.FILE_ENCODING)
    
    return df_doc_word[df_doc_word[col_names.DIC_WORD] == feature_word]
    
def merge_summary(df : pd.DataFrame, how = 'left'):
    
    p = re.compile(r'(?i)Summary.*\.csv$')
    d = local_files.TEXT_SUMMARY
    
    summary_df = pd.DataFrame(columns = [col_names.REPORT_ID, col_names.SUMMARY])
    for root, dirs, files in os.walk(d):
        for f in files:
            if p.search(f) is not None:
                tmp_df = pd.read_csv(os.path.join(root, f), 
                                 encoding = file_names.FILE_ENCODING, 
                                 engine = 'python',
                                 index_col = col_names.REPORT_ID,
                                 usecols = [col_names.REPORT_ID, col_names.SUMMARY],
                                 dtype = {col_names.REPORT_ID : str}
                                 )
                tmp_df = pd.merge(tmp_df, df[[col_names.REPORT_ID]], 
                                  how = 'inner',
                                  left_index = True,
                                  right_on = [col_names.REPORT_ID])
                summary_df = pd.concat([summary_df, tmp_df], sort = False)

    return pd.merge(df, summary_df, how = how, on = [col_names.REPORT_ID])

def merge_sec_master(df : pd.DataFrame, how = 'left'):
    
    sec_master_f = file_names.SEC_MASTER_FILE
    sec_master_df = pd.read_csv(sec_master_f, 
                            encoding = file_names.FILE_ENCODING, 
                            engine = 'python',
                            dtype = {'4ケタコード': str}
                            )
    new_columns = {'4ケタコード' : col_names.SEC_CODE, '構成銘柄' : col_names.SEC_NAME}
    sec_master_df = sec_master_df.rename(columns = new_columns)
    
    return pd.merge(df, sec_master_df, how = how, on = [col_names.SEC_CODE])
    
def merge_broker_master(df : pd.DataFrame, how = 'left'):
    
    broker_master = pd.DataFrame.from_dict(brokers.brokers, orient = 'index', columns = [col_names.BROKER_NAME])
    broker_master.index.name = col_names.BROKER_ID
    broker_master.index = broker_master.index.astype(str)
    
    return pd.merge(df, broker_master, how = how, left_on = [col_names.BROKER_ID], right_index = True)
    
def merge_pdf_table(df : pd.DataFrame, how = 'left'):
    
    report_pdf_f = file_names.REPORT_PDF_FILE
    df_report_pdf = pd.read_csv(report_pdf_f, 
                          encoding = file_names.FILE_ENCODING,
                          engine = 'python',
                          dtype = {col_names.SEC_CODE : str}
                          )
    
    return pd.merge(df, df_report_pdf, how = how, on = [col_names.REPORT_ID])
    
def merge_score_table(df : pd.DataFrame):
    '''
    ベクトルベースのセンチメントスコア＆教師データ
    '''
    v_score_f = os.path.join(file_names.HOME_DIR, 'scores', 'vector_scores.csv')
    usecols = [col_names.REPORT_ID, 
               col_names.SCORE_SENTI,
               col_names.SCORE_SENTI + '_Pred',
               col_names.SCORE_RECOMM,
               col_names.SCORE_RECOMM + '_Pred',
               ]
    new_columns = {
               col_names.SCORE_SENTI : col_names.SCORE_SENTI_REF,
               col_names.SCORE_SENTI + '_Pred' : col_names.SCORE_SENTI_V,
               col_names.SCORE_RECOMM : col_names.SCORE_RECOMM_REF,
               col_names.SCORE_RECOMM + '_Pred' : col_names.SCORE_RECOMM,
            }
    v_score_df = pd.read_csv(v_score_f, 
                          encoding = file_names.FILE_ENCODING,
                          engine = 'python',
                          index_col = col_names.REPORT_ID,
                          usecols = usecols,
                          dtype = {col_names.REPORT_ID : str}
                          )
    v_score_df = v_score_df.rename(columns = new_columns)
    int_cols = [col_names.SCORE_SENTI_V, col_names.SCORE_RECOMM]
    # 計算値を整数に変換
    v_score_df[int_cols] = v_score_df[int_cols].applymap(int)
    out_df = pd.merge(df, v_score_df, how = 'left', left_on = [col_names.REPORT_ID], right_index = True)
    '''
    極性値ベースのセンチメントスコア
    '''
    pn_score_f = os.path.join(file_names.HOME_DIR, 'scores', 'pn_scores.csv')
    pn_score_df = pd.read_csv(pn_score_f, 
                          encoding = file_names.FILE_ENCODING,
                          engine = 'python',
                          index_col = col_names.REPORT_ID,
                          usecols = [col_names.REPORT_ID, col_names.SENTI_SCORE],
                          dtype = {col_names.REPORT_ID: str}
                          )
    pn_score_df = pn_score_df.rename(columns = {col_names.SENTI_SCORE : col_names.SCORE_SENTI_PN})
    # 計算値を整数に変換
    pn_score_df[col_names.SCORE_SENTI_PN] = pn_score_df[col_names.SCORE_SENTI_PN].apply(int)
    
    out_df = pd.merge(out_df, pn_score_df, how = 'left', left_on = [col_names.REPORT_ID], right_index = True)

    return out_df

def search_reports(sec_code : str, feature_word = None, sbase = None):
    '''
    銘柄コード、特徴用語によるレポート一覧検索
    '''
    out_df = read_word_item_table(sec_code)
    
    out_cols = [col_names.REPORT_ID,
                col_names.SEC_CODE,
                col_names.SEC_NAME,
                col_names.BROKER_NAME,
                col_names.REPORT_DATE,
                col_names.PDF_PATH,
                col_names.SUMMARY,
                ]
    sort_cols = [col_names.REPORT_DATE]

    if feature_word is None:
        sbase == 'vector'
    else:
        out_cols  += [col_names.DIC_WORD, col_names.WORD_FREQ]
        sort_cols += [ col_names.WORD_FREQ]
        
        df_doc_word = read_doc_word_table(feature_word)
        out_df = pd.merge(out_df, df_doc_word, how = 'inner', on = [col_names.REPORT_ID])
    
    if sbase == 'pn':
        # 極性値によるセンチメントスコア
        out_cols += [col_names.SCORE_SENTI_PN, 
                     col_names.SCORE_SENTI_V, 
                     col_names.SCORE_SENTI_REF,
                     col_names.SCORE_RECOMM,
                     col_names.SCORE_RECOMM_REF,
                     ]
    else:
        # ベクトルによるセンチメントスコア
        out_cols += [col_names.SCORE_SENTI_V, 
                     col_names.SCORE_SENTI_PN, 
                     col_names.SCORE_SENTI_REF,
                     col_names.SCORE_RECOMM,
                     col_names.SCORE_RECOMM_REF,
                     ]
    
    out_df = merge_pdf_table(out_df)
    out_df = merge_sec_master(out_df)
    out_df = merge_broker_master(out_df)
    
    out_df = merge_score_table(out_df)
    
    out_df = out_df.drop_duplicates().sort_values(by = sort_cols, ascending  = False)
    out_df[col_names.SEC_CODE] = sec_code
    
    out_df = merge_summary(out_df)
    
    return out_df[out_cols]
