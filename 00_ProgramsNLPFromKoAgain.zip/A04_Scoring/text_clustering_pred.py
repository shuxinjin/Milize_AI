# -*- coding: utf-8 -*-
'''
Name        : text_clustering.py
Purpose     : 文章ベクトルのクラスタリング(NRI論文③)
Created Date: 2018.08.08
Created by  : Wenfeng Huang (Milize Inc.)
Updated Date: 2018.08.08
Updated by  : Wenfeng Huang (Milze Inc.)
'''
import sys
sys.path.append('../A50_Config')
sys.path.append('../A90_utils')

import argparse
import datetime
from   dateutil.relativedelta  import relativedelta
from   distutils.util          import strtobool
import pandas                  as     pd
import os
import re
from   sklearn                 import neighbors

from   A50_Config.config_roll  import date_settings
from   A50_Config.config_roll  import doc_clustering
from   A50_Config.config_roll  import file_names
from   A50_Config.config_roll  import flags
from   A50_Config.config_roll  import roll
from   A90_utils.localIO       import create_outdir
from   .config_scoring         import col_names
from   .text_clustering_train  import text_clustering_train
from   .text_clustering_train  import sec_clustering
from   .text_clustering_train  import conbine_cluster_col
    
class text_clustering_pred(text_clustering_train):

    _log_prefix = 'nri/current_roll/cluster/t_clust_pred'
    
    def _load_teacher_clusters(self):
        '''
        教師クラスタファイル読み込み
        '''
        return pd.read_csv(self._file_names.TEXT_CLUSTER_TRAIN_FILE, \
                           encoding = self._file_names.FILE_ENCODING, \
                           index_col = col_names.REPORT_ID, \
                           engine = 'python', \
                           )
    
        
    def _clustering(self, teacher_doc_clusters, doc_vectors, n_neighbor):
        '''
        文章のクラスタリング
        '''
        X_test = doc_vectors
#        print(X_test.head())
        
        clf_result = neighbors.KNeighborsClassifier(n_neighbor, weights = 'distance') # weights = 'uniform'
        # K分割交差検証（cross validation）による性能評価
        col_filter = lambda x : x.upper() not in [col_names.DOC_CLUSTER.upper(), col_names.SEC_CODE.upper()]
        col_cluster = lambda x : x.upper() == col_names.DOC_CLUSTER.upper()
        x_cols = list(filter(col_filter, teacher_doc_clusters.columns))
        y_cols = list(filter(col_cluster, teacher_doc_clusters.columns))[0]

        X_teacher = teacher_doc_clusters.loc[:, x_cols]
        Y_teacher = teacher_doc_clusters.loc[:, y_cols]
#        print('X_teacher :', X_teacher.shape)
#        print('X_test    :', X_test.shape)
#        scores = cross_validation.cross_val_score(clf_result, X_teacher, Y_teacher, cv = 10)
#        self._log("正解率平均値 = {}".format(scores.mean()))
#        self._log("正解率標準偏差 = {}".format(scores.std()))
#        self._log("Cross validation finished.")
        clf_result.fit(X_teacher, Y_teacher)
#        pred_Y = clf_result.predict(X_teacher)
#        ac_score = metrics.accuracy_score(Y_teacher, pred_Y)
#        self._log("正答率 = {}".format(ac_score))
        self._log("K-Neighbor training finished.")
        
        pred_test = clf_result.predict(X_test)
        self._log("K-Neighbor prediction finished.")
        
        return pred_test
        
    def main(self, item_file, create_flg = True):

        self._pred_start = datetime.date(self._pred_end.year, self._pred_end.month, 1)
        
        self._log('Prediction Start: {} Prediction End: {}'.format(self._pred_start.strftime('%Y/%m/%d'), self._pred_end.strftime('%Y/%m/%d')))
        
        if os.path.exists(self._file_names.TEXT_SEC_CLUSTER_PRED_FILE) \
           and os.path.exists(self._file_names.TEXT_CLUSTER_PRED_FILE) \
           and not create_flg:
            self._log('Use existing clusters.')
        else:
            df = self._read_doc_vector(self._file_names.TEXT_VECTOR_PRED_FILE)
            if len(df) == 0:
                self._log('No report to be clustered.')
                return
            df.sort_index(inplace = True)
    
            doc_vectors = df.values
    
            # クラスタリング
            teacher_doc_clusters = self._load_teacher_clusters()
            n_neighbor = doc_clustering.n_neighbor
            clusters = self._clustering(teacher_doc_clusters = teacher_doc_clusters, doc_vectors = doc_vectors, n_neighbor = n_neighbor)
            self._log('Document clustering finished.')
            
            # クラスタリング結果追加
            df[col_names.DOC_CLUSTER] = clusters

            # 銘柄列追加
            report_val = self._read_filtering_filename(item_file, self._pred_start, self._pred_end)
            f_sec = lambda x : str(report_val.loc[x, col_names.SEC_CODE])
            df[col_names.SEC_CODE] = list(map(f_sec, df.index))
    
            # 銘柄ごとのクラスタ確認
            sec_cluster_df = sec_clustering(df_cluster = df, sec_col = col_names.SEC_CODE)
            create_outdir(self._file_names.TEXT_SEC_CLUSTER_PRED_FILE)
            sec_cluster_df.to_csv(self._file_names.TEXT_SEC_CLUSTER_PRED_FILE, encoding=self._file_names.FILE_ENCODING)
            self._log('Securities clustering finished.')
    
            # 銘柄ごとのクラスタによるレポートのクラスタ補正
            col_cluster = conbine_cluster_col('MS')
            f_revise = lambda x : sec_cluster_df.loc[x, col_cluster] - 1
            df[col_names.DOC_CLUSTER] = list(map(f_revise, df[col_names.SEC_CODE]))
            # output to csv file
            create_outdir(self._file_names.TEXT_CLUSTER_PRED_FILE)
            df.to_csv(self._file_names.TEXT_CLUSTER_PRED_FILE, encoding=self._file_names.FILE_ENCODING)
            self._log('Document clustering revised.')

#if __name__ == '__main__':
#    
#    parser = argparse.ArgumentParser()
#    parser.add_argument('-i', '--is_from_ini', choices=['True', 'False'], default = 'False', required = False)
#    parser.add_argument('-s', '--start_date', default = None, required = False)
#    parser.add_argument('-e', '--end_date', default = None, required = False)
#
#    args = parser.parse_args()
#    is_from_ini = bool(strtobool(args.is_from_ini))
#    if is_from_ini:
#        start_date = date_settings.START_DATE
#        end_date   = date_settings.END_DATE
#    else:
#        current_date = datetime.datetime.now()
#        month_start  = datetime.datetime(current_date.year, current_date.month, 1)
#        start_date = month_start if args.start_date is None else datetime.datetime.strptime(args.start_date, '%Y/%m/%d')
#        end_date   = current_date if args.end_date is None else datetime.datetime.strptime(args.end_date, '%Y/%m/%d')
#
#    month_start = datetime.date(start_date.year, start_date.month, 1)
#    next_month = month_start + relativedelta(months = 1)
#    month_end = next_month + relativedelta(days = -1)
#
#    train_start = month_start + relativedelta(months = -roll.ROLL_WINDOW)
#    train_end = month_start + relativedelta(days = -1)
#    pred_end = month_end
#
#    str_month = start_date.strftime('%Y-%m')
#    str_year = start_date.strftime('%Y')
#    report_item_file = re.sub('.csv', '_{}.csv'.format(str_month), file_names.RECORD_ITEMS)
#    out_report_item_file = '{}/{}/{}/{}'.format(file_names.META_DIR, str_year, str_month, report_item_file)
#    
#    with text_clustering_pred(train_start, train_end, pred_end) as tcp:
#        tcp.main(out_report_item_file, create_flg = flags.create_flg_clustering_pred)
