# -*- coding: utf-8 -*-
'''
Name        : text_clustering.py
Purpose     : 文章ベクトルのクラスタリング(NRI論文③)
Created Date: 2018.08.08
Created by  : Wenfeng Huang (Milize Inc.)
Updated Date: 2018.08.08
Updated by  : Wenfeng Huang (Milze Inc.)
'''
import sys
sys.path.append('../A50_Config')
sys.path.append('../A90_utils')

import argparse
import datetime
from   dateutil.relativedelta   import relativedelta
from   distutils.util           import strtobool
import operator                 as     op
import os
import pandas                   as     pd
import re
from   sklearn.cluster          import KMeans

from   A50_Config.config_roll   import date_settings
from   A50_Config.config_roll   import doc_clustering
from   A50_Config.config_roll   import file_names
from   A50_Config.config_roll   import flags
from   A50_Config.config_roll   import roll
from   A90_utils.localIO        import create_outdir
from   .config_scoring          import col_names
from   .text_roll_base          import text_roll_base

def conbine_cluster_col(key):
    return 'cls_{}_{}'.format(doc_clustering.doc_cluster, key)
    
def sec_clustering(df_cluster, sec_col):
    '''
    銘柄ごとのクラスタリング情報
    '''

    out_cols = []
    
    for cls in range(doc_clustering.doc_cluster):
        out_cols.append(conbine_cluster_col(cls + 1)) # クラスタごとの度数分布
        
    out_cols.append(conbine_cluster_col('MS'))    # 最大可能なクラスタ番号
        
#    df_cluster[sec_col] = df_cluster[sec_col].astype(str)
    sec_codes = list(sorted(set(df_cluster[df_cluster[col_names.SEC_CODE] != ''][sec_col])))
    
    if len(sec_codes) > 0:
        sec_cluster_df = pd.DataFrame(index = sec_codes, columns = out_cols)
        sec_cluster_df.index.names = [sec_col]
        
        for sec in sec_codes:
            # 同じ銘柄に対して、文章クラスタの分布
            freq = df_cluster[df_cluster[sec_col] == sec].groupby(col_names.DOC_CLUSTER).size()
            for key in freq.keys():
                # クラスタごとの度数分布
                sec_cluster_df.loc[sec, conbine_cluster_col(key + 1)] = freq[key]
            # 最大可能なクラスタ
            sec_cluster_df.loc[sec, conbine_cluster_col('MS')] = max(freq.items(), key = lambda x : x[1])[0] + 1
    
        return sec_cluster_df
    else:
        return pd.DataFrame(columns = out_cols)

class text_clustering_train(text_roll_base):

    _log_prefix = 'nri/current_roll/cluster/t_clust_train'
        
    def _read_filtering_filename(self, item_file, start_date, end_date):
        df = pd.read_csv(item_file, 
                         encoding = self._file_names.FILE_ENCODING, 
                         engine = 'python',
                         parse_dates = [col_names.REPORT_DATE],
                         dtype = {col_names.SEC_CODE : str}
                         )
#        print(item_file)
#        df = df[~pd.isnull(df[col_names.SEC_CODE])]
#        idx = op.and_(op.ge(df[col_names.REPORT_DATE], start_date), op.le(df[col_names.REPORT_DATE], end_date))
#        return df[idx].set_index([col_names.REPORT_ID])
        return df.set_index([col_names.REPORT_ID])
        
    def _read_doc_vector(self, vector_file):
        return pd.read_csv(vector_file,
                           encoding = self._file_names.FILE_ENCODING,
                           index_col = [col_names.REPORT_ID],
                           engine = 'python',
                           )

    def _clustering(self, doc_vectors, n_clusters):
        '''
        文章のクラスタリング
        '''
        return KMeans( 
                      n_clusters   = n_clusters,
                      max_iter     = doc_clustering.clust_max_iter,
                      tol          = doc_clustering.clust_tol,
                      random_state = doc_clustering.clust_random_state).fit_predict(doc_vectors)
        
    def main(self, item_file, create_flg = False):
        
        self._log('Training Start: {} Training End: {}'.format(self._train_start.strftime('%Y/%m/%d'), self._train_end.strftime('%Y/%m/%d')))
        if os.path.exists(self._file_names.TEXT_SEC_CLUSTER_TRAIN_FILE) \
           and os.path.exists(self._file_names.TEXT_CLUSTER_TRAIN_FILE) \
           and not create_flg:
            self._log('Use existing clusters.')
        else:
            df = self._read_doc_vector(self._file_names.TEXT_VECTOR_FILE)
            df.sort_index(inplace = True)
    
            doc_vectors = df.values
    
            # クラスタリング
            n_clusters = doc_clustering.doc_cluster
            clusters = self._clustering(doc_vectors = doc_vectors, n_clusters = n_clusters)
            self._log('Document clustering finished.')
            
            # クラスタリング結果追加
            df[col_names.DOC_CLUSTER] = clusters
            # 銘柄列追加
            report_val = self._read_filtering_filename(item_file, self._train_start, self._train_end)
#            print(report_val)
            def f_sec(x):
                return '' if report_val.loc[x, col_names.SEC_CODE] == 'nan' else report_val.loc[x, col_names.SEC_CODE]
#            f_sec = lambda x : report_val.loc[x, col_names.SEC_CODE]
            df[col_names.SEC_CODE] = list(map(f_sec, df.index))
            
            # 銘柄ごとのクラスタ確認
            sec_cluster_df = sec_clustering(df_cluster = df, sec_col = col_names.SEC_CODE)
            create_outdir(self._file_names.TEXT_SEC_CLUSTER_TRAIN_FILE)
            sec_cluster_df.to_csv(self._file_names.TEXT_SEC_CLUSTER_TRAIN_FILE, encoding = self._file_names.FILE_ENCODING)
            self._log('Securities clustering finished.')
    
            # 銘柄ごとのクラスタによるレポートのクラスタ補正
            if sec_cluster_df.shape[0] > 0:
                col_cluster = conbine_cluster_col('MS')
                f_revise = lambda x, y : y if x is '' else sec_cluster_df.loc[x, col_cluster] - 1
                df[col_names.DOC_CLUSTER] = list(map(f_revise, df[col_names.SEC_CODE], df[col_names.DOC_CLUSTER]))
            # output to csv file
            create_outdir(self._file_names.TEXT_CLUSTER_TRAIN_FILE)
            df.to_csv(self._file_names.TEXT_CLUSTER_TRAIN_FILE, encoding = self._file_names.FILE_ENCODING)
            self._log('Document clustering revised.')

#if __name__ == '__main__':
#    
#    parser = argparse.ArgumentParser()
#    parser.add_argument('-i', '--is_from_ini', choices=['True', 'False'], default = 'False', required = False)
#    parser.add_argument('-s', '--start_date', default = None, required = False)
#    parser.add_argument('-e', '--end_date', default = None, required = False)
#
#    args = parser.parse_args()
#    is_from_ini = bool(strtobool(args.is_from_ini))
#    if is_from_ini:
#        start_date = date_settings.START_DATE
#        end_date   = date_settings.END_DATE
#    else:
#        current_date = datetime.datetime.now()
#        month_start  = datetime.datetime(current_date.year, current_date.month, 1)
#        start_date = month_start if args.start_date is None else datetime.datetime.strptime(args.start_date, '%Y/%m/%d')
#        end_date   = current_date if args.end_date is None else datetime.datetime.strptime(args.end_date, '%Y/%m/%d')
#
#    month_start = datetime.date(start_date.year, start_date.month, 1)
#    next_month = month_start + relativedelta(months = 1)
#    month_end = next_month + relativedelta(days = -1)
#
#    train_start = month_start + relativedelta(months = -roll.ROLL_WINDOW)
#    train_end = month_start + relativedelta(days = -1)
#    pred_end = month_end
#
#    str_month = start_date.strftime('%Y-%m')
#    str_year = start_date.strftime('%Y')
#    report_item_file = re.sub('.csv', '_{}.csv'.format(str_month), file_names.RECORD_ITEMS)
#    out_report_item_file = '{}/{}/{}/{}'.format(file_names.META_DIR, str_year, str_month, report_item_file)
#    
#    with text_clustering_train(train_start, train_end, pred_end) as tct:
#        tct.main(out_report_item_file, create_flg = flags.create_flg_clustering)
