# coding: utf-8
'''
Name        : text_roll_base.py
Purpose     : テキストマイニングのローリング計算の基底クラス
Created Date: 2018.08.08
Created by  : Wenfeng Huang (Milize Inc.)
Updated Date: 2018.08.08
Updated by  : Wenfeng Huang (Milze Inc.)
'''
import sys
sys.path.append('../A90_utils')

from   A90_utils.m_txtm_base import m_txtm_base
from   .config_scoring       import file_names

class text_roll_base(m_txtm_base):

    def __init__(self, train_start, train_end, pred_end, logger = None):
        '''
        train_start: Training start date
        train_end  : Training end date
        pred_end   : Prediction end date
        
        '''
        super().__init__(logger)
        self._train_start = train_start
        self._train_end = train_end
        self._pred_end = pred_end
        self._file_names = file_names(train_start, train_end, pred_end)
