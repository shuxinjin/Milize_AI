# -*- coding: utf-8 -*-
'''
Name        : text_summary.py
Purpose     : テキストの要約作成
Created Date: 2018.08.17
Created by  : Wenfeng Huang (Milize Inc.)
Updated Date: 2018.08.17
Updated by  : Wenfeng Huang (Milze Inc.)
'''

import sys
sys.path.append('../A50_Config')
sys.path.append('../A90_utils')

import argparse
import codecs
import csv
import datetime
from   dateutil.relativedelta   import relativedelta
from   distutils.util           import strtobool
import MeCab
import numpy                    as     np
import os
import pandas                   as     pd
import re

from   A50_Config.config_roll   import date_settings
from   A50_Config.config_roll   import file_names
from   A50_Config.config_roll   import roll
from   A50_Config.config_roll   import parameter_sum
from   A90_utils.localIO        import get_filelist
from   A90_utils.localIO        import get_io_subdirs
from   A90_utils.localIO        import create_outdir
from   A90_utils.textnorm       import normalize_neologd
from   .config_scoring          import col_names
from   .text_roll_base          import text_roll_base


codecs.register_error('ignore', lambda e: ('', e.end))
mecab = MeCab.Tagger('-Owakati')

def isNotEmpty(x):
    return re.fullmatch('[\s　]*', x) is None

def sent_tokenize(text):
    if len(text) < 10:
        return []
    else:
        text = re.sub('[\r\n。]+', '。', text)
    text = mecab.parse(normalize_neologd(text))
    
    sentences = []
    sentence = []
    for word in text.split():
        sentence.append(word)
        if(word == '。'):
            sentences.append(sentence)
            sentence = []
            
    return sentences

def get_freqdict(sentences):
    freqdict = {}
    for sentence in sentences:
        for word in sentence:
            freqdict.setdefault(word, 0.)
            if len(word) > 1:
                freqdict[word] += 1
    return freqdict

def cal_scores(sentences, freqdict, word_features):
    scores = []
    feature_dict = {}
    for sentence in sentences:
        sent_score = 0.0
        len_s = 0
        for word in sentence:
            if len(word) > 1:
                if word_features is None:
                    # Basic summarization model
                    sent_score += np.log(freqdict[word])
                else:
                    # Summarization model with position feature
                    feature_dict.setdefault(word, 0.0)
                    feature_dict[word] += 1
                    sent_score += np.log(freqdict[word]) * word_features(feature_dict[word], freqdict[word])
                len_s += len(word)
        if len_s > 0:
            sent_score /= len_s
        scores.append(sent_score)
    return scores

def direct_proportion(i, n):
    return float(n-i+1)/n

def inverse_proportion(i, n):
    return 1.0 / i

def geometric_sequence(i, n):
    return 0.5 ** (i-1)

def inverse_entropy(p):
    if p == 1.0 or 0.0:
        return 1.0
    return 1-(-p*np.log(p) - (1-p)*np.log(1-p))

def inverse_entropy_proportion(i, n):
    p = i / n
    return inverse_entropy(p)

def summarize(text, limit = 80, **options):
    '''
    text: target text
    limit: summary length limit
    option: 
    -m: summarization mode
        0: basic summarization model
        1: using word position feature
    -f: feature function
        0: direct proportion (DP)
        1: inverse proportion (IP)
        2: Geometric sequence (GS)
        4: Inverse entropy 
    '''
    sentences = sent_tokenize(text)
    freqdict = get_freqdict(sentences)

    # options['m'] == 0
    word_features = None
    
    if options['m'] == 1:
        if options['f'] == 0:
            word_features = direct_proportion
        elif options['f'] == 1:
            word_features = inverse_proportion
        elif options['f'] == 2:
            word_features = geometric_sequence
        elif options['f'] == 4:
            word_features = inverse_entropy_proportion

    scores = cal_scores(sentences, freqdict, word_features)

    topics = []
    length = 0

    for index in sorted(range(len(scores)), key = lambda k : scores[k], reverse = True):
        length += len(''.join(sentences[index]))
        if length <= limit:
            topics.append(index)
        else:
            break
    
    topics = sorted(topics)
    return ''.join([''.join(sentences[topic]) for topic in topics])

class text_summary(text_roll_base):

    _log_prefix = '/t_token'
        
    def _read_filtering_filename(self, item_file):
        
        df = pd.read_csv(item_file, 
                         encoding = self._file_names.FILE_ENCODING, 
                         engine = 'python', 
                         dtype = {col_names.REPORT_ID : str})
#        filtered_files = set([str(val) for val in target_df.ix[:,col_names.REPORT_ID]])
        filtered_files = set(df[col_names.REPORT_ID])
        # 重複ファイル取り除き
        return filtered_files, df

    def _read_text(self, in_file):
        
        sum_limit = parameter_sum.sum_limit
        sum_m     = parameter_sum.sum_m
        sum_f     = parameter_sum.sum_f
        with open(in_file, 'r', encoding = 'utf-8') as f:
            self._log('Summarizing: {}'.format(in_file))
            return summarize(f.read(), limit = sum_limit, m = sum_m, f = sum_f)
    
    def _read_dir_text(self, io_dirs, in_ext, out_ext):
        # 拡張子を除いたファイル名

        body_f = lambda x : str(re.sub(r'(?i){}'.format(in_ext), '', os.path.basename(x)))
        filter_f = lambda x : x in self._matched_files

        out_en = 'shift_jis'
        for (in_path, out_path) in io_dirs:
            # read files
            files = get_filelist(in_path, in_ext)
            for file in files:
                report_id = body_f(file)
                if filter_f(report_id):
                    out_file = os.path.join(out_path, '{}{}'.format(os.path.splitext(file)[0], out_ext))
                    # ignore finished files
                    if not os.path.exists(out_file):
                        
                        in_file = os.path.join(in_path, file)
                        create_outdir(out_file)
                        summary = self._read_text(in_file)
                        
                        item_f = os.path.join(out_path, 'Summary.csv')
                        if not os.path.exists(item_f):
                            with open(item_f, mode = 'w', encoding = out_en, newline = '') as o:
                                cols = list(self._item_df.columns) + [col_names.SUMMARY, col_names.WORD_COUNT]
                                csv.writer(o).writerow(cols)
#                                print('\t'.join(cols), file = o)
                        
                        with open(out_file, 'w', encoding = out_en, errors = 'ignore') as o, \
                             open(item_f,   'a', encoding = out_en, errors = 'ignore', newline = '') as o_item:
                            item_record = self._item_df[self._item_df[col_names.REPORT_ID] == report_id]
                            
                            item = ['' if item_record[x].isnull().any() else item_record[x].apply(str).values[0] for x in item_record]
                            csv.writer(o_item).writerow(item + [summary, len(summary)])
#                            print('\t'.join(item + [summary]), file = o_item)
                            print(summary, file = o)
                        # 重複防止
                        self._matched_files.remove(report_id)
            sub_io_dirs = get_io_subdirs(in_path, out_path)
            self._read_dir_text(sub_io_dirs, in_ext, out_ext)
    
    def main(self, item_file):
        
        self._log('Training Start: {} Training End: {}'.format(self._train_start.strftime('%Y/%m/%d'), self._train_end.strftime('%Y/%m/%d')))

        self._matched_files, self._item_df = self._read_filtering_filename(item_file)
        
        dir_in = np.ravel([self._file_names.CLNS_DIR])
        dir_out = self._file_names.TEXT_SUMMARY
        
        io_dirs = [(path_i, dir_out) for path_i in dir_in]
        in_ext = out_ext = '.txt'
        
        self._read_dir_text(io_dirs, in_ext, out_ext)
    
#if __name__ == '__main__':
#    
#    parser = argparse.ArgumentParser()
#    parser.add_argument('-i', '--is_from_ini', choices=['True', 'False'], default = 'False', required = False)
#    parser.add_argument('-s', '--start_date', default = None, required = False)
#    parser.add_argument('-e', '--end_date', default = None, required = False)
#
#    args = parser.parse_args()
#    is_from_ini = bool(strtobool(args.is_from_ini))
#    if is_from_ini:
#        start_date = date_settings.START_DATE
#        end_date   = date_settings.END_DATE
#    else:
#        current_date = datetime.datetime.now()
#        month_start  = datetime.datetime(current_date.year, current_date.month, 1)
#        start_date = month_start if args.start_date is None else datetime.datetime.strptime(args.start_date, '%Y/%m/%d')
#        end_date   = current_date if args.end_date is None else datetime.datetime.strptime(args.end_date, '%Y/%m/%d')
#
#    month_start = datetime.date(start_date.year, start_date.month, 1)
#    next_month = month_start + relativedelta(months = 1)
#    month_end = next_month + relativedelta(days = -1)
#
#    train_start = month_start + relativedelta(months = -roll.ROLL_WINDOW)
#    train_end = month_start + relativedelta(days = -1)
#    pred_end = month_end
#
#    str_month = start_date.strftime('%Y-%m')
#    str_year = start_date.strftime('%Y')
#    report_item_file = re.sub('.csv', '_{}.csv'.format(str_month), file_names.RECORD_ITEMS)
#    out_report_item_file = '{}/{}/{}/{}'.format(file_names.META_DIR, str_year, str_month, report_item_file)
#    
#    with text_summary(train_start, train_end, pred_end) as tt:
#        tt.main(out_report_item_file)
