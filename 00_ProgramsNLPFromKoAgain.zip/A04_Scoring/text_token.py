# -*- coding: utf-8 -*-
'''
Name        : text_token.py
Purpose     : テキストのトーケン化(NRI論文①)
Created Date: 2018.08.08
Created by  : Wenfeng Huang (Milize Inc.)
Updated Date: 2018.08.08
Updated by  : Wenfeng Huang (Milze Inc.)
'''

import sys
sys.path.append('../A50_Config')
sys.path.append('../A90_utils')

import argparse
import codecs
import datetime
from   dateutil.relativedelta   import relativedelta
from   distutils.util           import strtobool
import MeCab
import numpy                    as     np
import os
import pandas                   as     pd
import re

from   A50_Config.config_roll   import date_settings
from   A50_Config.config_roll   import file_names
from   A50_Config.config_roll   import roll
from   A90_utils.localIO        import get_filelist
from   A90_utils.localIO        import get_io_subdirs
from   A90_utils.localIO        import create_outdir
from   A90_utils.textnorm       import normalize_neologd
from   .config_scoring          import col_names
from   .text_roll_base          import text_roll_base
    
class text_token(text_roll_base):

    _log_prefix = '/t_token'
        
    def _read_filtering_filename(self, item_file):
        
        df = pd.read_csv(item_file, encoding = self._file_names.FILE_ENCODING, engine = 'python')
#        filtered_files = set([str(val) for val in target_df.ix[:,col_names.REPORT_ID]])
        filtered_files = set(df[col_names.REPORT_ID].map(str))
        # 重複ファイル取り除き
        return filtered_files

    def _read_text(self, in_file, out_file):
        codecs.register_error('ignore', lambda e: ('', e.end))
        
        isNotEmpty = lambda x : re.fullmatch('[\s　]*', x) is None
        
        out_en = 'shift_jis'
        with open(in_file, 'r', encoding = 'utf-8') as f, \
             open(out_file, 'w', encoding = out_en, errors = 'ignore') as o:
    
            self._log('Reading: {}'.format(in_file))
                
            article = ''
            mecab = MeCab.Tagger('-Owakati')
            for line in f:
                line = re.sub('[\r\n]+', '', line)
                if isNotEmpty(line):
                    article += line
            print(mecab.parse(normalize_neologd(article)), file = o)
    
    def _read_dir_text(self, io_dirs, in_ext, out_ext):
        # 拡張子を除いたファイル名

        body_f = lambda x : str(re.sub(r'(?i){}'.format(in_ext), '', os.path.basename(x)))
        filter_f = lambda x : x in self._matched_files

        for (in_path, out_path) in io_dirs:
            # read files
            files = get_filelist(in_path, in_ext)
            for file in files:
                report_id = body_f(file)
                if filter_f(report_id):
                    out_file = os.path.join(out_path, '{}{}'.format(os.path.splitext(file)[0], out_ext))
                    # ignore finished files
                    if not os.path.exists(out_file):
                        in_file = os.path.join(in_path, file)
                        create_outdir(out_file)
                        self._read_text(in_file, out_file)
                        # 重複防止
                        self._matched_files.remove(report_id)
                    
            sub_io_dirs = get_io_subdirs(in_path, out_path)
            self._read_dir_text(sub_io_dirs, in_ext, out_ext)
    
    def main(self, item_file):
        
        self._log('Training Start: {} Training End: {}'.format(self._train_start.strftime('%Y/%m/%d'), self._train_end.strftime('%Y/%m/%d')))

        self._matched_files = self._read_filtering_filename(item_file)
        
        dir_in = np.ravel([self._file_names.CLNS_DIR])
        dir_out = self._file_names.TEXT_TOKEN
        
        io_dirs = [(path_i, dir_out) for path_i in dir_in]
        in_ext = out_ext = '.txt'
        
        self._read_dir_text(io_dirs, in_ext, out_ext)
    
#if __name__ == '__main__':
#    
#    parser = argparse.ArgumentParser()
#    parser.add_argument('-i', '--is_from_ini', choices=['True', 'False'], default = 'False', required = False)
#    parser.add_argument('-s', '--start_date', default = None, required = False)
#    parser.add_argument('-e', '--end_date', default = None, required = False)
#
#    args = parser.parse_args()
#    is_from_ini = bool(strtobool(args.is_from_ini))
#    if is_from_ini:
#        start_date = date_settings.START_DATE
#        end_date   = date_settings.END_DATE
#    else:
#        current_date = datetime.datetime.now()
#        month_start  = datetime.datetime(current_date.year, current_date.month, 1)
#        start_date = month_start if args.start_date is None else datetime.datetime.strptime(args.start_date, '%Y/%m/%d')
#        end_date   = current_date if args.end_date is None else datetime.datetime.strptime(args.end_date, '%Y/%m/%d')
#
#    month_start = datetime.date(start_date.year, start_date.month, 1)
#    next_month = month_start + relativedelta(months = 1)
#    month_end = next_month + relativedelta(days = -1)
#
#    train_start = month_start + relativedelta(months = -roll.ROLL_WINDOW)
#    train_end = month_start + relativedelta(days = -1)
#    pred_end = month_end
#
#    str_month = start_date.strftime('%Y-%m')
#    str_year = start_date.strftime('%Y')
#    report_item_file = re.sub('.csv', '_{}.csv'.format(str_month), file_names.RECORD_ITEMS)
#    out_report_item_file = '{}/{}/{}/{}'.format(file_names.META_DIR, str_year, str_month, report_item_file)
#    
#    with text_token(train_start, train_end, pred_end) as tt:
#        tt.main(out_report_item_file)
