# -*- coding: utf-8 -*-
'''
Name        : text_vector.py
Purpose     : テキストのトーケン化とバイアス除去
Created Date: 2018.08.08
Created by  : Wenfeng Huang (Milize Inc.)
Updated Date: 2018.10.09
Updated by  : Wenfeng Huang (Milze Inc.)
'''
import numpy as np
#import tensorflow as tf
#import random as rn
import os

#os.environ['PYTHONHASHSEED'] = '0'
#np.random.seed(777)
#rn.seed(12345)
#
#session_conf = tf.ConfigProto(intra_op_parallelism_threads=1, inter_op_parallelism_threads=1)
#
#from keras import backend as K

# The below tf.set_random_seed() will make random number generation
# in the TensorFlow backend have a well-defined initial state.
# For further details, see: https://www.tensorflow.org/api_docs/python/tf/set_random_seed

#tf.set_random_seed(1234)

#sess = tf.Session(graph=tf.get_default_graph(), config=session_conf)
#K.set_session(sess)


import warnings
warnings.filterwarnings(action = 'ignore', category = UserWarning, module = 'gensim')
import sys
sys.path.append('../A50_Config')
sys.path.append('../A90_utils')

from   gensim                   import models
from   gensim.models.doc2vec    import TaggedDocument
import MeCab
#import numpy                    as     np
#import os
import pandas                   as     pd
import re

from   A50_Config.config_roll   import doc_vectorizing
from   A90_utils.localIO        import create_outdir
from   .config_scoring          import brokers
from   .config_scoring          import col_names
from   .search_func             import read_uniq_mapping
from   .text_roll_base          import text_roll_base
    
class text_vector(text_roll_base):

    _log_prefix = 'vector/t_vect'
    
    _uniq_mapping = None

    def __init__(self, train_start, train_end, pred_end, logger = None):
        super().__init__(train_start, train_end, pred_end, logger)
        self._uniq_mapping = read_uniq_mapping()
    
    def _corpus_files(self, directory):
        
        matched_records = set(self._matched_files[col_names.REPORT_ID].map(str))
        body_f = lambda x : str(re.sub(r'(?i){}'.format('.txt'), '', x))
        filter_f = lambda x : body_f(x) in matched_records
        corpus = []
        for d in directory:
            for root, dirs, files in os.walk(d):
                for file in list(filter(filter_f, files)):
                    corpus.append(os.path.join(root, file))
        return corpus
    
    def _read_document(self, path):
            
        with open(path, 'r', encoding = 'shift_jis') as f:
            return f.read()

    def _split_into_words(self, doc, name = ''):
            
        mecab = MeCab.Tagger("-Ochasen")
        lines = mecab.parse(doc).splitlines()
        words = []
        for line in lines:
            chunks = line.split('\t')
            if len(chunks) > 3 and (chunks[3].startswith('動詞') or chunks[3].startswith('形容詞') or (chunks[3].startswith('名詞') and not chunks[3].startswith('名詞-数'))):
                if chunks[0] in self._uniq_mapping:
#                    words.append(chunks[0])
                    words.append(self._uniq_mapping[chunks[0]])
        return TaggedDocument(words = words, tags = [name])

    def _corpus_to_sentences(self, corpus):
        docs = [self._read_document(x) for x in corpus]
        sentences = []
        for idx, (doc, name) in enumerate(zip(docs, corpus)):
            if (idx + 1) % 1000 == 0:
                self._log('\r前処理中 {} / {}'.format(idx + 1, len(corpus)))
            sentences.append(self._split_into_words(doc, re.sub('(?i).txt', '', os.path.basename(name))))
        return sentences
        
    def _train(self, sentences):

        # set workers = 1 to return a deterministic result for each run
#        print('Python hash seed:', os.environ['PYTHONHASHSEED'])
        try:
            
            model = models.Doc2Vec(          
                                   documents = sentences,
                                   dm        = doc_vectorizing.vec_dm,
                                   size      = doc_vectorizing.vec_window_size,
                                   window    = doc_vectorizing.vec_window,
                                   alpha     = doc_vectorizing.vec_alpha,
                                   min_alpha = doc_vectorizing.vec_min_alpha,
                                   min_count = doc_vectorizing.vec_min_count,
                                   sample    = doc_vectorizing.vec_sample,
                                   workers   = doc_vectorizing.vec_workers,
#                                   seed = 777,
                                   )
            epoch = 10
            for _ in range(epoch):
                if sys.version_info.minor > 5:
                    model.train(sentences, total_examples = model.corpus_count, epochs = model.epochs)
                else:
                    model.train(sentences, total_examples = model.corpus_count, epochs = model.iter)
                model.alpha -= 0.002  # decrease the learning rate
                model.min_alpha = model.alpha  # fix the learning rate, no decay
                '''
                ranks = []
                for doc_id in range(100):
                    inferred_vector = model.infer_vector(sentences[doc_id].words)
                    sims = model.docvecs.most_similar([inferred_vector], topn = len(model.docvecs))
                    rank = [docid for docid, sim in sims].index(sentences[doc_id].tags[0])
                    ranks.append(rank)
                self._log(collections.Counter(ranks))
                '''
            return model
        except Exception as e:
            self._log(e)
            self._log(sentences)
            return None
        
    def _mean_bias(self, model, broker_id):
        '''
        Return: 発行体該当の文章平均ベクトル, 対象文章ID一覧
        '''
        # 発行体該当のレポート
#        broker_reports = set([str(row[col_names.REPORT_ID]) for _, row in self._matched_files[self._matched_files[col_names.BROKER_ID] == broker_id].iterrows()])
        broker_reports = set(self._matched_files[self._matched_files[col_names.BROKER_ID] == broker_id][col_names.REPORT_ID].map(str))
        #print(broker_reports)
        f_filter = lambda x : x in broker_reports
        
        # 平均ベクトル算出
        # row_filter: ベクトル化済みの発行体該当のレポートID
        row_filter = list(filter(f_filter, model.docvecs.doctags.keys()))
#        self._log(row_filter[:20])
#        self._log(list(model.docvecs.doctags.keys())[:20])
#        self._log([row_filter])
#        print(model.docvecs['2017060149621600'])
        if np.count_nonzero(row_filter) > 0:
#            return np.mean(model.docvecs[row_filter], axis = 0), row_filter
            return np.mean([model.docvecs[r_id] for r_id in row_filter], axis = 0), row_filter
        else:
            return None, None
        
    def _remove_bias(self, model):
        
        dic_doc_vectors = {}
        for broker in brokers.brokers.keys():
            mean_d, row_filter = self._mean_bias(model, broker)
            if mean_d is not None:
                for docid in row_filter:
                    dic_doc_vectors[docid] = model.docvecs[docid] - mean_d
        
        return dic_doc_vectors

    def _read_filtering_filename(self, item_file, start_date, end_date):
        df = pd.read_csv(item_file, 
                         encoding = self._file_names.FILE_ENCODING, 
                         engine = 'python',
                         parse_dates = [col_names.REPORT_DATE])
#        df = df[~pd.isnull(df[col_names.SEC_CODE])]
#        idx = op.and_(op.ge(df[col_names.REPORT_DATE], start_date), op.le(df[col_names.REPORT_DATE], end_date))
#        return df.loc[idx, [col_names.REPORT_ID, col_names.REPORT_DATE, col_names.BROKER_ID]]
        return df[[col_names.REPORT_ID, col_names.REPORT_DATE, col_names.BROKER_ID]]

    def main(self, item_file, create_flg = False):
        self._log('Training Start: {} Training End: {}'.format(self._train_start.strftime('%Y/%m/%d'), self._train_end.strftime('%Y/%m/%d')))

        self._matched_files = self._read_filtering_filename(item_file, self._train_start, self._train_end)
#        print(self._matched_files.head())
        self._log('Matched: {}'.format(self._matched_files.shape))
        
        dir_in = np.ravel([self._file_names.TEXT_TOKEN])
        out_model = self._file_names.TEXT_DOC2VEC_MODEL
        if os.path.exists(out_model) and not create_flg:
            model = models.Doc2Vec.load(out_model)
        else:
            corpus = self._corpus_files(dir_in)
            self._log('Corpus finished.')
            sentences = self._corpus_to_sentences(corpus)
            self._log('Sentences finished.')
            model = self._train(sentences)
            self._log('Training finished.')
            if model is not None:
                create_outdir(out_model)
                model.save(out_model)
                self._log('Model saved.')
            
        if os.path.exists(self._file_names.TEXT_VECTOR_FILE) and not create_flg:
            self._log('Use existing vectors.')
        else:
            # バイアス除去し、Data Frame に変換
            if model is not None:
                df = pd.DataFrame.from_dict(self._remove_bias(model), orient = 'index')
                df.index.names = [col_names.REPORT_ID]
                self._log('Broker bias removed.')
                # ベクトルをCSVファイルに出力
                create_outdir(self._file_names.TEXT_VECTOR_FILE)
                df.to_csv(self._file_names.TEXT_VECTOR_FILE, encoding = self._file_names.FILE_ENCODING)
                self._log('Vectors saved.')
        
#if __name__ == '__main__':
#    
#    parser = argparse.ArgumentParser()
#    parser.add_argument('-i', '--is_from_ini', choices=['True', 'False'], default = 'False', required = False)
#    parser.add_argument('-s', '--start_date', default = None, required = False)
#    parser.add_argument('-e', '--end_date', default = None, required = False)
#
#    args = parser.parse_args()
#    is_from_ini = bool(strtobool(args.is_from_ini))
#    if is_from_ini:
#        start_date = date_settings.START_DATE
#        end_date   = date_settings.END_DATE
#    else:
#        current_date = datetime.datetime.now()
#        month_start  = datetime.datetime(current_date.year, current_date.month, 1)
#        start_date = month_start if args.start_date is None else datetime.datetime.strptime(args.start_date, '%Y/%m/%d')
#        end_date   = current_date if args.end_date is None else datetime.datetime.strptime(args.end_date, '%Y/%m/%d')
#
#    month_start = datetime.date(start_date.year, start_date.month, 1)
#    next_month = month_start + relativedelta(months = 1)
#    month_end = next_month + relativedelta(days = -1)
#
#    train_start = month_start + relativedelta(months = -roll.ROLL_WINDOW)
#    train_end = month_start + relativedelta(days = -1)
#    pred_end = month_end
#
#    str_month = start_date.strftime('%Y-%m')
#    str_year = start_date.strftime('%Y')
#    report_item_file = re.sub('.csv', '_{}.csv'.format(str_month), file_names.RECORD_ITEMS)
#    out_report_item_file = '{}/{}/{}/{}'.format(file_names.META_DIR, str_year, str_month, report_item_file)
#    
#    with text_vector_train(train_start, train_end, pred_end) as tvt:
#        tvt.main(out_report_item_file, create_flg = flags.create_flg_vectorizing)
