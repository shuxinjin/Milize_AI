# coding: utf-8
'''
Name        : NN_Config.py
Purpose     : NNの設定ファイル
Created Date: 2018.02.19
Created by  : Wenfeng Huang (MILIZE Inc.)
Updated Date: 2018.02.19
Updated by  : Wenfeng Huang (MILIZE Inc.)
'''
import sys
sys.path.append('./')

import  os
import  configparser
from    datetime               import datetime
from   .NN_namedtuple          import Target_Param
from   .NN_namedtuple          import NN_Param
from   .NN_namedtuple          import Batch_Param
from   .NN_namedtuple          import Model_Param
from   .NN_Mdl_CNN             import NN_Mdl_CNN
from   .NN_Mdl_RF              import NN_Mdl_RF
from   .NN_Mdl_XGBoost         import NN_Mdl_XGBoost

file_encoding = 'shift_jis'

cfg = configparser.ConfigParser()
cfg.read(os.path.join(os.path.dirname(__file__), 'NN_Config.ini'), encoding = 'utf-8')

# 方式設定
target_param = Target_Param(
        # 現在日付
#        current_date  = datetime.strptime(cfg['target_settings']['current_date'], '%Y/%m/%d'),
        current_date  = datetime.now(),
        )

batch_param = Batch_Param(
        # 木の数
        tree_Size      = cfg['batch_param'].getint('tree_Size'), 
        trainRatio     = cfg['batch_param'].getfloat('trainRatio'), 
        )

nn_param = NN_Param(
        lr            = cfg['nn_param'].getfloat('lr'), 
        initializer   = cfg['nn_param']['initializer'], 
        inActivation  = cfg['nn_param']['inActivation'], 
        outActivation = cfg['nn_param']['outActivation'], 
        dropoutValue  = cfg['nn_param'].getfloat('dropoutValue'), 
        x_norm        = cfg['nn_param']['x_norm'],
        y_norm        = cfg['nn_param']['y_norm'],
        f_loss        = cfg['nn_param']['f_loss'],
        f_opt         = cfg['nn_param']['f_opt'],
        stopTime      = cfg['nn_param'].getint('stopTime'),
        analyzeCount  = cfg['nn_param'].getint('analyzeCount'),
        stopDistance  = cfg['nn_param'].getfloat('stopDistance'),
        epochCount    = cfg['nn_param'].getint('epochCount'),
        )

nn_model = Model_Param(
        name          = cfg['nn_model']['model'],
        model         = globals()[cfg['nn_model']['model']],
        )

