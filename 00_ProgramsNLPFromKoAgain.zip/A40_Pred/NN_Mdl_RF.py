# coding: utf-8
'''
Name        : NN_Mdl_RF.py
Purpose     : NN Random Forest モデル
Created Date: 2018.10.10
Created by  : Wenfeng Huang (MILIZE Inc.)
Updated Date: 2018.10.10
Updated by  : Wenfeng Huang (MILIZE Inc.)
'''

import sys
sys.path.append('../A90_utils')

import numpy                  as     np
import os
import pickle
import traceback

from   sklearn.ensemble       import RandomForestRegressor as regressor
from   sklearn.metrics        import mean_squared_error
from   sklearn.metrics        import mean_absolute_error

from   A90_utils.localIO      import create_outdir
from   .NN_Mdl                import NN_Mdl

class NN_Mdl_RF(NN_Mdl):
    
    _log_prefix = 'RF_Model'
    
    def recreate_DataX(self, X, look_back = 1):
        return X
#        dataX = []
#        for i in range(len(X) - look_back + 1):
#            dataX.append(np.ravel(X[i: i + look_back]))
#        return np.array(dataX)
    
    # NN 作成
    def _buildModel(self, oldModel = None):

        # モデルの作成
        try:
            self._destroyModel(oldModel)
            
#            model = regressor(n_estimators  = self._batch_param.tree_Size, 
#                              max_features = 'log2',
#                              )  # インスタンスの生成　木の数を指定
            model = regressor(n_estimators = self._batch_param.tree_Size, 
                              random_state = 777, # 固定
                              )  # インスタンスの生成　木の数を指定
            
            return model
            
        except Exception as e:
            info = ['モデル作成失敗']
            info.extend(e.args)
            info.extend(traceback.format_tb(e.__traceback__))
            self._log('\n'.join(info))
            
            self._destroyModel(model)
            
            return None

    def _model_fit(self, model, X, Y):
#        print(Y.shape)
        model.fit(X, Y)
        
    # NN 訓練
    def Train(self):
        
        # 学習データ作成
        self._splitTrainData()
        
        yPred_train = [] # Y予測値
        yPred_test = [] # Y予測値
        
        model = self._buildModel()
        try:
            # 学習
            if self._yTrain.shape[1] > 1:
                self._model_fit(model, self._xTrain, self._yTrain)
            else:
                self._model_fit(model, self._xTrain, self._yTrain.ravel())
                
            yPred_train = model.predict(self._xTrain)
            yPred_test  = model.predict(self._xTest)
            if self._nn_param.f_loss == 'MSE':
                # Mean squared error
                err_train = mean_squared_error(yPred_train, self._yTrain)
                err_test  = mean_squared_error(yPred_test, self._yTest)
            else:
                # Mean absolute error
                err_train = mean_absolute_error(yPred_train, self._yTrain)
                err_test  = mean_absolute_error(yPred_test, self._yTest)
                
            self._log('training loss = {0:.4}, test loss = {1:.4}'.format(err_train, err_test))
            
#            if len(np.ravel(yPred_train) == 1):
#                yPred_train = yPred_train.reshape(1, -1)
#                yPred_test  = yPred_test.reshape(1, -1)
#            return np.ravel(self._y_scaler.inverse_transform(yPred_train)/100), np.ravel(self._y_scaler.inverse_transform(yPred_test)/100)
        
            return yPred_train, yPred_test
            
        except Exception as e:
            info = ['学習失敗']
            info.extend(e.args)
            info.extend(traceback.format_tb(e.__traceback__))
            self._log('\n'.join(info))
            
            self._destroyModel(model)
            
    def Save(self, file_name, model):
        
        self._feature_importances = model.feature_importances_
        
#        exts = ['pickle', 'x_scaler', 'y_scaler']
#        models = [model, self._x_scaler, self._y_scaler]
        exts = ['pickle']
        models = [model]
        for e, m in zip(exts, models):
            full_name = '{}.{}'.format(file_name, e)
            create_outdir(full_name)
            with open(full_name, mode = "wb") as o:
                pickle.dump(m, o)
        
    def Load(self, file_name):
        
#        exts = ['pickle', 'x_scaler', 'y_scaler']
        exts = ['pickle']
        models = []
        for e in exts:
            full_name = '{}.{}'.format(file_name, e)
            if os.path.exists(full_name):
                with open(full_name, mode = "rb") as f:
                    models.append(pickle.load(f))
            else:
#                self._model, self._x_scaler, self._y_scaler = None, None, None
                self._model = None
                return
                
#        self._model, self._x_scaler, self._y_scaler = models
        self._model = models[0]
        
            
    def _destroyModel(self, model):
        '''
        モデル削除
        '''
        try:
            if model is not None:
                del model
        except Exception as e:
            info = ['モデル削除失敗']
            info.extend(e.args)
            info.extend(traceback.format_tb(e.__traceback__))
            self._log('\n'.join(info))
