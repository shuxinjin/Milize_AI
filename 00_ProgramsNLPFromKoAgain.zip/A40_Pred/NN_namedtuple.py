# coding: utf-8
'''
Name        : NN_namedtuple.py
Purpose     : NNのタイプ定義ファイル
Created Date: 2018.04.26
Created by  : Wenfeng Huang (MILIZE Inc.)
Updated Date: 2018.04.26
Updated by  : Wenfeng Huang (MILIZE Inc.)
'''

from   collections            import namedtuple

t_params = (
            'current_date',   # 現在日付
           )

n_params = (
            'lr',             # 学習率
            'initializer',    # 初期重み関数
            'inActivation',   # 入力活性化関数
            'outActivation',  # 出力活性化関数
            'dropoutValue',   # Dropout率
            'x_norm',         # 入力Xデータの正規化・平準化関数
            'y_norm',         # 出力Yデータの正規化・平準化関数
            'f_loss',         # 損失関数
            'f_opt',          # 最適化関数
            'stopTime',       # 停止時間
            'analyzeCount',   # 実行回数
            'stopDistance',   # 停止誤差基準（学習誤差とテスト誤差の差）
            'epochCount',     # １回の学習のエポック数
           )

b_params = (
            'tree_Size',       # 木の数
            'trainRatio',      # 学習の割合
           )

mdl_params = (
            'name',           # モデル名
            'model',          # モデルクラス
           )

Target_Param  = namedtuple('target_Param', t_params)
NN_Param      = namedtuple('NN_Param', n_params)
Batch_Param   = namedtuple('Batch_Param', b_params)
Model_Param   = namedtuple('Model_Param', mdl_params)
