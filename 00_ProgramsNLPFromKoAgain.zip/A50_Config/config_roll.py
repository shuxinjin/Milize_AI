# -*- coding: utf-8 -*-
'''
Name        : config_roll.py
Purpose     : スコア化用の設定モジュール
Created Date: 2018.08.08
Created by  : Wenfeng Huang (MILIZE Inc.)
Updated Date: 2018.08.08
Updated by  : Wenfeng Huang (MILIZE Inc.)
'''

import configparser
from datetime import datetime
import os

cfg_r = configparser.ConfigParser()
config_r = os.path.join(os.path.dirname(__file__), './config_roll.ini')
cfg_r.read(config_r, encoding='utf-8')


class flags:
    create_flg_tokenizing = cfg_r['flags'].getboolean('create_flg_tonenizing')
    create_flg_clustering = cfg_r['flags'].getboolean('create_flg_clustering')
    create_flg_clustering_pred = cfg_r['flags'].getboolean(
                                    'create_flg_clustering_pred')
    create_flg_standard = cfg_r['flags'].getboolean('create_flg_standard')
    create_flg_vectorizing = cfg_r['flags'].getboolean('create_flg_vectorizing')
    create_flg_vectorizing_pred = cfg_r['flags'].getboolean(
                                    'create_flg_vectorizing_pred')
    create_flg_scoring = cfg_r['flags'].getboolean('create_flg_scoring')
    output_train_flg = cfg_r['flags'].getboolean('output_train_flg')


class date_settings:
    START_DATE = datetime.strptime(cfg_r['date_settings']['START_DATE'],
                                   '%Y/%m/%d')
    END_DATE = datetime.strptime(cfg_r['date_settings']['END_DATE'],
                                 '%Y/%m/%d')


class data_constant:
    change_criteria = cfg_r['data_constant'].getfloat('change_criteria')
    prof_pattern = cfg_r['data_constant'].getint('prof_pattern')
    score_threshold = cfg_r['data_constant'].getfloat('score_threshold')


class roll:
    ROLL_WINDOW = cfg_r['roll'].getint('ROLL_WINDOW')
    ROLL_STEP_LEN = cfg_r['roll'].getint('ROLL_STEP_LEN')
    DAILY_DATES = cfg_r['roll'].getint('DAILY_DATES')
    MONTHLY_MONTHS = cfg_r['roll'].getint('MONTHLY_MONTHS')


class doc_clustering:
    # cluster number
    doc_cluster = cfg_r['doc_clustering'].getint('doc_cluster')
    # 最大繰り返し回数
    clust_max_iter = cfg_r['doc_clustering'].getint('clust_max_iter')
    # 許容誤差
    clust_tol = cfg_r['doc_clustering'].getfloat('clust_tol')
    # 乱数初期値
    clust_random_state = cfg_r['doc_clustering'].getint('clust_random_state')
    # 近傍法探索個数
    n_neighbor = cfg_r['doc_clustering'].getint('n_neighbor')


class doc_vectorizing:
    # 文章のベクトル化
    vec_dm = cfg_r['doc_vectorizing'].getint('vec_dm')
    vec_window_size = cfg_r['doc_vectorizing'].getint('vec_window_size')
    vec_window = cfg_r['doc_vectorizing'].getint('vec_window')
    vec_alpha = cfg_r['doc_vectorizing'].getfloat('vec_alpha')
    vec_min_alpha = cfg_r['doc_vectorizing'].getfloat('vec_min_alpha')
    vec_min_count = cfg_r['doc_vectorizing'].getint('vec_min_count')
    vec_sample = cfg_r['doc_vectorizing'].getfloat('vec_sample')
    # 再現性重視のため、１のみ
    vec_workers = cfg_r['doc_vectorizing'].getint('vec_workers')


class word_vectorizing:

    # 単語のベクトル化
    vec_size = cfg_r['word_vectorizing'].getint('vec_size')
    vec_window = cfg_r['word_vectorizing'].getint('vec_window')
    vec_workers = cfg_r['word_vectorizing'].getint('vec_workers')
    vec_min_count = cfg_r['word_vectorizing'].getint('vec_min_count')
    vec_iter = cfg_r['word_vectorizing'].getint('vec_iter')

    word_cluster = cfg_r['word_vectorizing'].getint('word_cluster')
    cluster_max_iter = cfg_r['word_vectorizing'].getint('cluster_max_iter')
    cluster_tol = cfg_r['word_vectorizing'].getfloat('cluster_tol')
    cluster_random_state = cfg_r['word_vectorizing'].getint(
                                'cluster_random_state')

    word_topn = cfg_r['word_vectorizing'].getint('word_topn')

#    noise_pattern = cfg_r['word_vectorizing']['noise_pattern']
    noise_pattern = '|'.join(
                    [
                        '[!-~\s:-@ ,、.「」【】～■◆✔\--]+',
                        '[①-㉚]+',
                        '[ぁ-んァ-ン]',
                        '(ため)',
                        '(こと)',
                        '(よう)',
                        '(から)',
                        '(など)',
                        '¢/',
                        '≪≫',
                        '≫。',
                        '×OS',
                        '÷EBITDA',
                        '÷TOPIX',
                        '↑:',
                        '→\-',
                        '⇒\-',
                        '→\$',
                        '→\+',
                        '→±',
                        '↓:',
                        '※\)',
                        '※:',
                        '∞」',
                            ]
                    )


class common_file_names:
    d = os.path.join(os.path.dirname(__file__), '../../')
    # d = '../'
    # text folder
    TEXT_HOME_DIR = os.path.join(d, cfg_r['file_names']['TEXT_HOME_DIR'])
    # Cleansing result  folder
    CLNS_DIR = os.path.join(d, cfg_r['file_names']['CLNS_DIR'])
    # Home directory for following processes
    HOME_DIR = os.path.join(d, cfg_r['file_names']['HOME_DIR'])
    # Master directory
    MASTER_DIR = os.path.join(d, cfg_r['file_names']['MASTER_DIR'])
    # PDF folder
    PDF_DIR = os.path.join(d, cfg_r['file_names']['PDF_DIR'])
    # html folder
    HTML_HOME_DIR = os.path.join(d, cfg_r['file_names']['HTML_HOME_DIR'])


class file_names(object):

    FILE_ENCODING = 'shift_jis'

    TEXT_HOME_DIR = os.path.abspath(common_file_names.TEXT_HOME_DIR)
    CLNS_DIR = os.path.abspath(common_file_names.CLNS_DIR)
    HOME_DIR = os.path.abspath(common_file_names.HOME_DIR)
    MASTER_DIR = os.path.abspath(common_file_names.MASTER_DIR)
    PDF_DIR = os.path.abspath(common_file_names.PDF_DIR)
    HTML_HOME_DIR = os.path.abspath(common_file_names.HTML_HOME_DIR)

    META_DIR = '{}/current_rolling/record_items'.format(HOME_DIR)
    RECORD_BROKERS = 'report_brokers.csv'
    RECORD_ITEMS = 'record_items.csv'

    SEC_MASTER_FILE = os.path.join(MASTER_DIR, 'out_master_securities.csv')

    INIT_USER_DIC_FILE = os.path.join(MASTER_DIR, 'User.csv')
    DOC_WORD_FILE = os.path.join(MASTER_DIR, 'doc_word_table.csv')
    REPORT_PDF_FILE = os.path.join(MASTER_DIR, 'report_pdf_table.csv')

    UNIQ_MAP_FILE = os.path.join(MASTER_DIR, 'word_count_unique.csv')

    TEXT_SENTENCES_FILE = '{}/word_vector/word_sentences.pkl'.format(HOME_DIR)
    TEXT_WORD2VEC_MODEL = '{}/word_vector/ana_word2vec.model'.format(HOME_DIR)
    WORD_COUNT = '{}/word_vector/word_count.csv'.format(HOME_DIR)
    WORD_COUNT_ITEM = '{}/word_vector/word_count_item.csv'.format(HOME_DIR)

    WORD_VECTOR_FILE = '{}/word_vector/word_vector.csv'.format(HOME_DIR)
    WORD_CLUSTER_FILE = '{}/word_vector/ana_word_cluster.csv'.format(HOME_DIR)

    WORD_NET_HTML = '{}/html/word_net.html'.format(HOME_DIR)


class parameter_sum:
    # 文字数制限参考値
    sum_limit = cfg_r['summarize'].getint('sum_limit')
    #
    # モデル
    #    0 = 簡易モデル（Basic Summarization Model）
    #    1 = 単語位置特徴モデル（Word Position Feature Model）
    #
    sum_m = cfg_r['summarize'].getint('sum_m')
    #
    # モデルオプション
    #    0: direct proportion (DP)
    #    1: inverse proportion (IP)
    #    2: Geometric sequence (GS)
    #    4: Inverse entropy
    #
    sum_f = cfg_r['summarize'].getint('sum_f')


class view_param:
    # 関連用語の表示数
    topn = cfg_r['view_param'].getint('topn')
    # 関連度合いの閾値
    threshold = cfg_r['view_param'].getfloat('threshold')
