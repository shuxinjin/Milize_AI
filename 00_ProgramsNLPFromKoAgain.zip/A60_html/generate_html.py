# -*- coding: utf-8 -*-
'''
Name        : generate_html.py
Purpose     : HTMLページ作成
Created Date: 2018.8.31
Created by  : Wenfeng Huang (MILIZE Inc.)
Updated Date: 2018.8.31
Updated by  : Wenfeng Huang (MILIZE Inc.)
'''
import os
import shutil
import sys
sys.path.append('../A90_utils')

from A90_utils.localIO import create_outdir

HTML_ENCODING = 'utf-8'


djangflag=True
sixlevel=False
tmplflag=True


import random





#add by jin
def filer(refer1, dtext):
    
    # {'name': '対照', 'x': 0, 'y': 0 , 'symbolSize':20, 'category': '相対','value': 76, 'symbol': 'circle', 'draggable' : 'True'},
#    line=""

    data1=""
    line1="{'name': '%s', 'x': 0, 'y': 0 , "    #if repeat in data nodes ,could not be showed 
 
    data1=line1 % (refer1)
    
    #or ,filter repeated
    if dtext.find(data1)>0:
        return True
    else:
        return False
#######################




def searchsixjson(indexword,sec_code,prob_to_plot_threshold,relationsmore):
  
    jsoncat4=''
    relations=relationsmore
    counti=10000#add by jin
    mainw=0#decide whether add "," or not add ,
    tmps=''#add by jin
    serformat= "{'name': '%s','ratio': '%s','codeid':'%s','link':'%s'},"
    serdata22=""

    for (refer, referred), prob in relations.items():
        # skip those less than threshold
        if indexword==refer:
      
            # skip those less than threshold
            if prob < prob_to_plot_threshold:
                continue
            #add by jin,category =1...if tmps==refer and (not mainw):
            if tmps==refer and (mainw):
                jsoncat4+=  ',\n'
            else:
                #another category 2 node
                if not (tmps == ''):
                    #IMportant to make it close words
                    if (not mainw):         
                        #jsoncat4+=     '   \n]},999\n'
                        jsoncat4+=     ',\n'
                    else:
                        pass
                
                #removerepeat(json_cat2, '   { \"name\": \"'+ referred +'\",     \"value\": \"'  +str(counti)+ '"       }')
                #jsoncat4+=   ' 0000{\"name\": \"'+ refer +  '\",   \"children\": ['          +'\n'
                ##jsoncat4+=   '0000,\n'
                counti=counti+1 #add by jin    
    
            jsoncat4+=   '                      { \"name\": \"'+ referred +'\",     \"value\": \"'  + str('%.03f'%prob) + '"       }'
            serdata22 +=  serformat % (referred, str('%.03f'%prob),sec_code,'reports')
          
            counti=counti+1 #add by jin
            #should add the complete child
            if tmps==refer:

                mainw=0
            else:
                #cat2 begin ,so dont repeat write and flag
                mainw=1
            tmps=refer
            ###### 
   
    
    
    return jsoncat4,serdata22

#end of searchsixjson****************




#add by jin
def getjson(relations,sec_name,sec_code, prob_to_plot_threshold,catbranch,relationsmore):
    prob_to_plot_threshold=0.3
    counti=1#add by jin
    mainww=0
    tmps=''#add by jin
    #the title you can change as your request
    #add by jin,JSON


  
    serformat= "{'name': '%s','ratio': '%s','codeid':'%s','link':'%s'},"
    serdata22=""

    
    json_cat3 = '{\n "name": "'+ sec_name  +'",  \n "children": [\n'
   
    
    
    category11=set()#add by jin
    category12=set()#add by jin

    
    for (refer, referred), prob in relations.items():
        # skip those less than threshold
        if prob < prob_to_plot_threshold:
            continue
        #add by jin,category =1
        if tmps==refer:
            pass
        else:
            #another category 2 node
            if not (tmps == ''):
                #IMportant to make it close words
                if (not mainww):      
                    json_cat3=  json_cat3[:-2]#remove "," 
                    json_cat3+=     '   \n]},\n'
                else:
                    pass
            if refer not in category11:
                    #removerepeat(json_cat2, '   { \"name\": \"'+ referred +'\",     \"value\": \"'  +str(counti)+ '"       }')
                    json_cat3+=   '{\"name\": \"'+ refer +  '\",   \"children\": ['          +'\n'
            counti=counti+1 #add by jin    
        category11.add(refer)#add by jin
        #not cat 1| json cat2 ,then can be add to cat 2 | json cat3
        category12.add(referred)#add by jin
        #    once complete children word, I dont care whether you repeat
        if tmps==refer:
            
            if sixlevel:
                tempjson=''
             
                ###应该在这里再递归一次child,if (referred in catbranch) and (referred not in sixadd):
                if (referred in catbranch) :
      
                    
                    json_cat3+=   '    { \"name\": \"'+ referred +'\",    \"children\": ['          +'\n'
                    
                    tempjson,serdata22 =searchsixjson(referred,sec_code,prob_to_plot_threshold,relationsmore)
                    
                    # the close of root|json cat1 
                    json_cat3=json_cat3+tempjson
                    json_cat3+=  '\n    ]   }'#add by jin,JSON
                   
                    #####
                    ####
                    ###
                    #
                    #change here
                   

            else:
                json_cat3 +=   '    { \"name\": \"'+ referred +'\",     \"value\": \"'  + str('%.03f'%prob) + '"       }'
              
                serdata22 +=  serformat % (referred, str('%.03f'%prob),sec_code,'reports')
          
            ################
            counti=counti+1 #add by jin
            mainww=0
            
            json_cat3+=  ',\n'
        else:
            #cat2 begin ,so dont repeat write and flag
            mainww=1
        tmps=refer
        ###### 
    json_cat3=  json_cat3[:-2]#remove ","
    json_cat3+=     '\n] }\n'
    # the close of root|json cat1 
    json_cat3+=  '] }\n'#add by jin,JSON
    
    return json_cat3,serdata22



def generate_html_more(sec_code, sec_name,relations,max_refer_prob, min_refer_prob,saved_dir,catbranch,relationsmore,prob_to_plot_threshold=0.3):
    
    print("enter intoo html more")    
    
#    current_dir = os.getcwd()
#    if djangflag:
#        current_dir='C:/JINSHUXIN/milize_dash/Word_Vect/00_Programs/' #corrected by jinjinjin
    
    current_dir = os.path.dirname(__file__)
    html_head_path = os.path.join(current_dir,  'html_head.txt')
    html_tail_path = os.path.join(current_dir,  'html_tail.txt')
    json_cat2=''
    json_cat2 ,serdata22  =getjson(relations,sec_name,sec_code, prob_to_plot_threshold,catbranch,relationsmore)
    
    #if tmplflag:
    #    return json_cat2

    #abstract info
    data_text2=""
    #data_text2="var seriesData = [ YOUR DATA HERE ];\n"
    data_text2="var seriesData = [ "+ serdata22 +"];\n"
    #data_text2=getyourfloatstr()
    data_text2=data_text2 \
    +"(function ($) { \n" \
    +"    var myChart = echarts.init(document.getElementById(\'main\'));\n" \
    +"    window.onresize = function () {\n" \
    +"        myChart.resize();\n" \
    +"    };\n"\
    +"    myChart.clear();\n"
    
    
    
    
    fnm=''
    fnm='j'+str(random.randint(100,200))
  
    

    #add by jin,echart cycle mouse on click event ####################### 
    dpath = os.path.split(saved_dir)#return list of path

    #add by jin ##json echart tree ##################### 
    jsonfile=''
    jsonfile='$.getJSON(\''+'{%static \'js/'+fnm+'.json\'%}'+ '\').done(function (data) { '   #'$.getJSON('data/d1.json').done(function (data) {
    jsonfile1=''
    jsonfile1='$.getJSON(\''+'js/'+fnm+'.json'+ '\').done(function (data) { '   #'$.getJSON('data/d1.json').done(function (data) {
             
    html_head_path2 = os.path.join(current_dir,  'jtree_top.txt')
    html_tail_path2 = os.path.join(current_dir,  'jtree_tail.txt')
    ########cycle tree##################################
    html_head_path3 = os.path.join(current_dir,  'jctree_top.txt')
    html_tail_path3 = os.path.join(current_dir,  'jctree_tail.txt')
    
    with open(html_head_path2, 'r', encoding = HTML_ENCODING) as f:
        head_text2 = f.read()
    with open(html_tail_path2, 'r', encoding = HTML_ENCODING) as f:
        tail_text2 = f.read()
    with open(html_head_path3, 'r', encoding = HTML_ENCODING) as f:
            head_text3 = f.read()
    with open(html_tail_path3, 'r', encoding = HTML_ENCODING) as f:
            tail_text3 = f.read()
  
    if djangflag:
        cwd = os.getcwd()
#        with open('C:/JINSHUXIN/Milize_AI/static/js/'+fnm+'.json', 'w', encoding ='utf-8') as f:
        with open(os.path.join(cwd, '../static/js/' + fnm + '.json'), 'w', encoding ='utf-8') as f:
            f.write(json_cat2)
#        with open('C:/JINSHUXIN/Milize_AI/Milize_AI/templates/cycle_tree.html', 'w', encoding = HTML_ENCODING) as f:
        with open(os.path.join(cwd, 'templates/'+'__'+sec_code+'.html'), 'w', encoding = HTML_ENCODING) as f:
            f.write(head_text2 + data_text2 +jsonfile+ tail_text2)
#        with open('C:/JINSHUXIN/Milize_AI/Milize_AI/templates/word_tree.html', 'w', encoding = HTML_ENCODING) as f:
        with open(os.path.join(cwd, 'templates/word_tree.html'), 'w', encoding = HTML_ENCODING) as f:
      
            f.write(head_text3 +jsonfile+ tail_text3)   
        
    else:
        
        with open(os.path.abspath(dpath[0])+'/js/'+fnm+'.json', 'w', encoding ='utf-8') as f:
            f.write(json_cat2)

        with open(os.path.abspath(dpath[0])++'__'+sec_code+'.html', 'w', encoding = HTML_ENCODING) as f:
            f.write(head_text2  +jsonfile1+ tail_text2)  #add the ABSTRACT

        with open(os.path.abspath(dpath[0])+'/word_tree.html', 'w', encoding = HTML_ENCODING) as f:
            f.write(head_text3 +jsonfile1+ tail_text3)       
    serdata22=""
    return ('__'+sec_code+'.html'),sec_name







def generate_html_page(quarter, sec_code, sec_name, relations, max_refer_prob, min_refer_prob, saved_dir, prob_to_plot_threshold=0.25):
    
    
    if quarter is None:
        html_file = os.path.join(saved_dir, 'word_net_{}'.format(sec_code))
        json_f = 'jword_{}.json'.format(sec_code)
    else:
        quarter_name = quarter[2]
        html_file = os.path.join(saved_dir, 'word_net_{}_{}'.format(sec_code, quarter_name))
        json_f = 'jword_{}_{}.json'.format(sec_code, quarter_name)
    
    current_dir = os.path.dirname(__file__)
    
    # copy javascript files
    for root, dirs, files in os.walk(os.path.join(current_dir, 'js')):
        for f in files:
            src = os.path.join(root, f)
            dst = os.path.join(saved_dir, 'js', f)
            if not os.path.exists(dst):
                create_outdir(dst)
                shutil.copy2(src, dst)
                
#    html_head_path = os.path.join(current_dir,  'html_head.txt')
#    html_tail_path = os.path.join(current_dir,  'html_tail.txt')

    min_link_width = 0.5
    max_link_width = 3.0

#    width_slope = (max_link_width - min_link_width) / (max_refer_prob - min_refer_prob)
    width_slope = max_link_width
    
  
    # format the links
   
    linkseries='var seriesLinks = [\n'#add by jin
    
    links_text = 'links: [\n'
    links_item_format = """{source: '%s', target: '%s',
    lineStyle:{normal:{width: %f}}},
    """
    
    #add by jin######
    links_item_format1 = """{'source': '%s', 'target': '%s'},"""
    ##############

    counti=1#add by jin
    data1_text = '\n'+' var seriesData = [\n'#add by jin
  
    #the title you can change as your request
#    json_cat2 = ' {\n "name": "特徴語関連",  \n "children": [\n'#add by jin,JSON
    json_cat2 = ' {\n "name": "' + sec_name + '",  \n "children": [\n'
    
    offset1=20 #add by jin
    tmps=''#add by jin
    category1=set()#add by jin
    category2=set()#add by jin

     
    filtered_words = set()
    
    for (refer, referred), prob in relations.items():
        # skip those less than threshold
        if prob < prob_to_plot_threshold:
            continue

        filtered_words.add(refer)
        
        #add by jin,category =1
        if tmps==refer:
            json_cat2+=  ',\n'
        else:
            #another category 2 node
            if not (tmps == ''):
                #IMportant to make it close words
                json_cat2+=     '   \n]},\n'
           
            data1_item_format = " {'name': '%s', 'x': %d, 'y': %d , 'symbolSize':%d, 'category': '%s','idvalue': %d, 'symbol': '%s', 'draggable' : 'True','ignore' :0, 'flag' :0},"+'\n'
            
            #{   "name": "节点1",   "children": [
            
            if not filer(refer,data1_text):
                    data1_text +=data1_item_format % (refer,  220,  1 , offset1,  refer   ,counti,'circle')
                    
                    counti=counti+1 #add by jin
            #use set() to make cat2 not repeat,cate0 only one root word ,no meaning .code be redo ,so keep the index        
            if refer not in category1:
                    json_cat2+=   ' {\"name\": \"'+ refer +  '\",   \"children\": ['          +'\n'
                        
                        
        tmps=refer
        category1.add(refer)#add by jin
        ######
        
        
        filtered_words.add(referred)
        
        #not cat 1| json cat2 ,then can be add to cat 2 | json cat3
        if referred not in category1:
            #if not repeat in ca2
            if referred not in category2:
                #add by jin,category =2
                data1_item_format = " {'name': '%s', 'x': %d, 'y': %d , 'symbolSize':%d, 'category': '%s','idvalue': %d, 'symbol': '%s', 'draggable' : 'True','ignore' :1, 'flag' :1},"+'\n'
                #data1_item_format = " {'name:' '%s', 'x': %d, 'y': %d , 'symbolSize':%d, 'category': '%d','value': %d, 'symbol': '%s', 'draggable' : 'True', 'id' :%d, 'ignore' :'False', 'flag' :'True'},"+'\n'
                if not filer(referred,data1_text):
                    data1_text +=data1_item_format % (referred,  0,  0 , offset1,  refer   ,counti,'circle')
                    counti=counti+1 #add by jin

            #repeat in ca2 | json cat 3
            else:
               
                data1_item_format = " {'name': '%s', 'x': %d, 'y': %d , 'symbolSize':%d, 'category': '%s','idvalue': %d, 'symbol': '%s', 'draggable' : 'True','ignore' :1, 'flag' :1},"+'\n'
                if not filer(referred,data1_text):
                    data1_text +=data1_item_format % (referred,  0,  0 , offset1,  refer   ,counti,'circle')
                    counti=counti+1 #add by jin
        category2.add(referred)#add by jin
        
        #    once complete children word, I dont care whether you repeat
        json_cat2+=   '   { \"name\": \"'+ referred +'\",     \"value\": \"'  + str('%.03f'%prob)+ '"       }'
        serdata22 += serformat % (referred, str('%.03f'%prob))
        serdata22 +=  serformat % (referred, str('%.03f'%prob),sec_code,'reports')
    
        ###### 
        
        
        #prob = np.sqrt(prob)
        line_width = min_link_width + width_slope * (prob - min_refer_prob)
        
        links_text += links_item_format % (refer, referred, line_width)
        
        linkseries += links_item_format1 % (refer, referred)#add by jin
        linkseries +='\n'#add by jin
        
        
        
    #  改写第一对的XY 为220，1    
    data1_text +=  '\n'+' ];\n' # add by jin 
   

    linkseries=linkseries+'\n '+'];\n'#add by jin
        
    links_text += '],\n'
    #print("links_text:",links_text)
   
    
    # format the node
    data_text = 'data:[\n'
    seriescategories = 'var seriesCategories = [\n'   # add by jin
    data_item_format = "{name: '%s'},\n"
    for word in filtered_words:
        data_text       += data_item_format % word
        seriescategories+= data_item_format % word#add by jin
    data_text += '],\n'
    
    seriescategories+='];\n'#add by jin
    #remove the last ,
   
    json_cat2+=     '\n ]  }\n'
    # the close of root|json cat1 
    json_cat2+=  '] }\n'#add by jin,JSON
   
    
    # read the head to compose the html file
#    with open(html_head_path, 'r', encoding = HTML_ENCODING) as f:
#        head_text = f.read()
#
#    # read the tail to compose the html file
#    with open(html_tail_path, 'r', encoding = HTML_ENCODING) as f:
#        tail_text = f.read()

    #add by jin,echart cycle mouse on click event ####################### 
#    html_head_path1 = os.path.join(current_dir,  'jhtml_top.txt')
#    html_tail_path1 = os.path.join(current_dir,  'jhtml_tail.txt')
#    with open(html_head_path1, 'r', encoding = HTML_ENCODING) as f:
#        head_text1 = f.read()
#    with open(html_tail_path1, 'r', encoding = HTML_ENCODING) as f:
#        tail_text1 = f.read()
  
#    with open(os.path.abspath(dpath[0])+'/j_net.html', 'w', encoding = HTML_ENCODING) as f:
#        f.write(head_text1 +data1_text+ linkseries + seriescategories + tail_text1)
    #####################################
    
    
    
    
    
    #add by jin ##json echart tree ##################### 
    
    
    html_head_path2 = os.path.join(current_dir,  'jtree_top.txt')
    html_tail_path2 = os.path.join(current_dir,  'jtree_tail.txt')
    with open(html_head_path2, 'r', encoding = HTML_ENCODING) as f:
        head_text2 = f.read()
    with open(html_tail_path2, 'r', encoding = HTML_ENCODING) as f:
        tail_text2 = f.read()
  
#    with open(os.path.abspath(dpath[0])+'/jword.json', 'w', encoding ='utf-8') as f:
    with open(os.path.join(saved_dir, json_f), 'w', encoding ='utf-8') as f:
        f.write(json_cat2)
  
    jsonfile=''
#    jsonfile='$.getJSON(\''+'jword.json'+ '\').done(function (data) { '   #'$.getJSON('data/d1.json').done(function (data) {
    jsonfile='$.getJSON(\''+ json_f + '\').done(function (data) { '   #'$.getJSON('data/d1.json').done(function (data) {
    print("jsonf::::",json_f)
    tree_f = html_file + '_tree.html'
    with open(tree_f, 'w', encoding = HTML_ENCODING) as f:
        f.write(head_text2 + jsonfile + tail_text2)
        
        
        
    ########cycle tree##################################
#    html_head_path3 = os.path.join(current_dir,  'jctree_top.txt')
#    html_tail_path3 = os.path.join(current_dir,  'jctree_tail.txt')
#    with open(html_head_path3, 'r', encoding = HTML_ENCODING) as f:
#        head_text3 = f.read()
#    with open(html_tail_path3, 'r', encoding = HTML_ENCODING) as f:
#        tail_text3 = f.read()
        
#    cycle_f = html_file + '_cycle.html'
#    with open(cycle_f, 'w', encoding = HTML_ENCODING) as f:
#        f.write(head_text3 + jsonfile + tail_text3)    
        
    #####################################
    
    
    
    # save the html file
    #print("data_text:",data_text)
#    with open(saved_html_file, 'w', encoding = HTML_ENCODING) as f:
#        f.write(head_text + data_text +links_text  + tail_text)
   
