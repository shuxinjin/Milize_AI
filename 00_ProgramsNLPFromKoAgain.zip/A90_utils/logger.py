# -*- coding: utf-8 -*-
'''
Name        : logger.py
Purpose     : ログ出力用モジュール
Created Date: 2018.08.03
Created by  : Wenfeng Huang (MILIZE Inc.)
Updated Date: 2018.08.03
Updated by  : Wenfeng Huang (MILIZE Inc.)
'''

import datetime
import os
import sys
import traceback

from localIO import create_empty_file

def send_mail(file_info, msg, error_flag):
    pass

class logger(object):

    '''
    out_option = 0: standard output device and logger
                 1: logger only
                 2: standard output device only
    '''
    _initialized = False
    def __init__(self, log_dir, log_prefix):
        self._log_dir = log_dir
        self._log_prefix = log_prefix
        # log_yyyymmdd_HHMM.txt
        timestamp = datetime.datetime.now()
        log_file = os.path.join(self._log_dir, timestamp.strftime("{}_%Y%m%d_%H%M%S.log").format(self._log_prefix))
        create_empty_file(log_file)
        self._log_file = log_file
        
    def __enter__(self):
        return self

    def log(self, info, file_info = None, error_flag = False, out_option = 0):
        if file_info is not None:
            send_mail(file_info = file_info, msg = info, error_flag = error_flag)
            
        with open(self._log_file, 'a', encoding = 'utf-8') as o:
            o_devices = [o, sys.stdout] if out_option == 0  else [o] if out_option == 1 else [sys.stdout]
            for device in o_devices:
                if type(info) is list:
                    for line in info:
                        print(line, file = device)
                else:
                    print(info, file = device)
                
    def start(self, parent, out_option = 0):
        timestamp = datetime.datetime.now()
        info = 'Start {} at {}'.format(parent, timestamp.strftime("%Y/%m/%d %H:%M:%S"))
        self.log(info, out_option)
        
    def end(self, parent, type, value, tb, out_option = 0):
        info = []
        if type is not None:
            info.append('{}: {}'.format(type.__name__, value, out_option))
        if tb is not None:
            info.extend(traceback.format_tb(tb))
            
        timestamp = datetime.datetime.now()
        info.append('End {} at {}'.format(parent, timestamp.strftime("%Y/%m/%d %H:%M:%S")))
        self.log('\n'.join(info), out_option)
