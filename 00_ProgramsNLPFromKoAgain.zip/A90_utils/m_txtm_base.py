# coding: utf-8
'''
Name        : m_txtm_base.py
Purpose     : テキストマイニング用の基底クラス
Created Date: 2018.08.03
Created by  : Wenfeng Huang (MILIZE Inc.)
Updated Date: 2018.08.03
Updated by  : Wenfeng Huang (MILIZE Inc.)
'''

from logger import logger

class m_txtm_base(object):

    _log_dir = '../log'
    _log_prefix = None
    _conf = None
    _logger = None
    
    def __init__(self, logger = None):
        self._logger = logger
    
    def __enter__(self):
        if self._logger is None:
            self._logger = logger(self._log_dir, self._log_prefix)
        self._logger.start(self.__class__.__name__)
        return self
        
    def __exit__(self, type, value, traceback):
        self._logger.end(self.__class__.__name__, type, value, traceback)
        
    def _log(self, info, file_info = None, error_flag = False, out_option = 0):
        self._logger.log(info = info, file_info = file_info, error_flag = error_flag, out_option = out_option)
