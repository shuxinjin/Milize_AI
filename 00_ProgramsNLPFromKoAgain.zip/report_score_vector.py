# -*- coding: utf-8 -*-
'''
Name        : report_score_vector.py
Purpose     : ベクトルによるレポートのスコア算出
Created Date: 2018.9.3
Created by  : Wenfeng Huang (MILIZE Inc.)
Updated Date: 2018.9.3
Updated by  : Wenfeng Huang (MILIZE Inc.)
'''
import datetime
from   A04_Scoring.text_score_vector import text_score_vector

if __name__ == '__main__':
    
    train_start = datetime.datetime.strptime('2015/08/01', '%Y/%m/%d')
    train_end   = datetime.datetime.strptime('2018/07/31', '%Y/%m/%d')
    pred_end    = train_end
    with text_score_vector(train_start, train_end, pred_end) as ts:
#        pass
        ts.main()
