# -*- coding: utf-8 -*-
'''
Name        : search_data.py
Purpose     : データ検索
Created Date: 2018.10.26
Created by  : Wenfeng Huang (MILIZE Inc.)
Updated Date: 2018.10.26
Updated by  : Wenfeng Huang (MILIZE Inc.)
'''

from A04_Scoring.search_func import search_reports
from A04_Scoring.sec_word_tree import search_word_tree

if __name__ == '__main__':
    
#    sec_code = '1878'
#    word = '住宅'
#    df = search_reports(sec_code, sbase = 'pn')
#    df.to_csv('xx.csv', encoding = 'shift_jis', index = False)
#    df = search_reports(sec_code, sbase = 'vector')
#    df.to_csv('yy.csv', encoding = 'shift_jis', index = False)
#    df = search_reports(sec_code, feature_word = word)
#    df.to_csv('zz.csv', encoding = 'shift_jis', index = False)
#    print(df.head())
    sec_code = '9810'
    html_data = search_word_tree(sec_code)
    print(html_data)
    
