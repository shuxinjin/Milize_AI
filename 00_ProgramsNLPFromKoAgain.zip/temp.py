# -*- coding: utf-8 -*-

#import requests
#import lxml.html
#requests.packages.urllib3.disable_warnings()
#
##csvへの書き出しに利用
#
## //*[@id="topics-category-all"]/div[1]/div[1]/ul/li[1]/a/text()
#
#web_url = "https://www.nhk.or.jp/bunken/research/yoron/political/2018.html"
#
#html = requests.get(web_url, verify = False)
##print(html)
#root = lxml.html.fromstring(html.content)
##print(html.content)
## data_1= root.xpath("//div[@id='topics-category-all']/div[1]/div[1]/ul/li["+str(i)+"]/a/text()")[0]
#
## //*[@id="naikaku"]/table/tbody/tr[2]/td[2]
##data_1= root.xpath("//section[@id='naikaku']/table/tbody/tr[2]/text()")
#data_1= root.xpath("//section[@id='naikaku']/table/tr[2]/td/text()")
#print(data_1)
#
## //*[@id="naikaku"]/table/tbody/tr[2]/td[2]
##for text in data_1:
##    print(text)

#import pandas as pd
#df = pd.DataFrame(
#        {'col1': [1, 2], 'col2': [0.5, 0.75]})
#df.set_index('col1', drop = True, inplace = True)
#print(df['col2'].values)
##print(df.to_dict()['col2'])
#print(df.to_dict('dict'))
#
#s1 = set([1,2,3])
#s2 = set([3,4,5])
#
#print(s1 & s2)
#print(s1 - s2)

#from gensim.models.doc2vec import TaggedDocument
# 
## 空のリストを作成（学習データとなる各文書を格納）
#training_docs = []
# 
## 各文書を表すTaggedDocumentクラスのインスタンスを作成
## words：文書に含まれる単語のリスト（単語の重複あり）
## tags：文書の識別子（リストで指定．1つの文書に複数のタグを付与できる）
#sent1 = TaggedDocument(words=['どーも', '谷口', 'です', 'よーし', 'やってく', 'ぞ'], tags=['d1'])
#print(sent1.words)
#s2 = set([3,4,5])
#s2 |= set([5,6,7])
#print(s2)
#list1 = [3,4,5]
#list1.extend([5,6,7])
#print(list1)

#from   datetime               import date, datetime
#from   dateutil.relativedelta import relativedelta
#
#def get_quarter(d):
#    y = d.year
#    q = int((d.month - 1)/3)
#    if q == 0:
#        q = 4
#        y -= 1
#    return '{}Q{}'.format(y, q)
#    
#year = 2018
#for i in range(1, 13):
#    q = int((i-1)/3)
#    start_m = datetime(year, q*3 + 1, 1)
#    end_m = start_m + relativedelta(months = 3) - relativedelta(days = 1)
#    print(i, ':', start_m, end_m, get_quarter(start_m))

#import matplotlib
# 
#print(matplotlib.matplotlib_fname())
#print(matplotlib.get_configdir())
#print(matplotlib.rcParams['font.family'])
#
#import matplotlib.font_manager as fm
#for font in fm.findSystemFonts():
#    prop = fm.FontProperties(fname = font) 
#    print(prop.get_name(), prop.get_family())
#    
#import matplotlib.pyplot as plt
#plt.figure()
#plt.xlabel('てすと')
#plt.title('テスト')    
#
#print(int(508*.7))
#import re
#from   collections              import Counter
#import pandas as pd
#words = ['x1', 'x1', 'x2', 'x3', 'x3']
#
#count = Counter(words)
#rows = sorted(count.items(), key=lambda x: -x[1])
#df = pd.DataFrame(data = rows, columns = ['Col1', 'Col2'])
#print(df)
#
#yy = '123.pdf'
#p = re.compile(r'(?i)\.pdf$')
#print(p.search(yy))
#print(p.sub(r'+++', yy))
#

import pandas as pd
import datetime

from A04_Scoring.search_func    import search_reports
from A04_Scoring.config_scoring import col_names

def get_quarter_name(d):
    y = d.year
    q = int((d.month - 1)/3)
    if q == 0:
        q = 4
        y -= 1
    return '{}_Q{}'.format(y, q)

def convert_Q(d_str):
    d = datetime.datetime.strptime(d_str, '%Y-%m-%d')
    return get_quarter_name(d)

def convert_fy(d_str):
    d = datetime.datetime.strptime(d_str, '%Y-%m-%d')
    month = d.month
    year  = d.year
    return year if month > 3 else year - 1

def convert_int(f_value):
    if pd.isnull(f_value):
        return None
    else:
        return int(f_value)
    
sec_codes = [
                2768,
                8001,
                8002,
                8015,
                8031,
                8053,
                8058,
                ]

col_name = 'FY_Q'
#col_name = 'FY'

df = pd.DataFrame()
for sec_code in sec_codes:
    tmp_df = search_reports(str(sec_code), sbase = 'vector')
#    tmp_df[col_name] = tmp_df[col_names.REPORT_DATE].apply(convert_fy)
    tmp_df[col_name] = tmp_df[col_names.REPORT_DATE].apply(convert_Q)
    df = df.append(tmp_df)
out_f = 'all_score.csv'
df.to_csv(out_f, encoding = 'shift_jis', index = False)
out_f_fy = 'all_score_{}.csv'.format(col_name)
df_fy = df.groupby(by = [col_names.SEC_CODE, col_names.SEC_NAME, col_name])[col_names.SCORE_SENTI_V, col_names.SCORE_SENTI_REF].mean().applymap(convert_int)
df_fy.to_csv(out_f_fy, encoding = 'shift_jis')

