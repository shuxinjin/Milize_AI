# -*- coding: utf-8 -*-
"""
Created on Fri Aug  3 10:19:52 2018

@author: sxjin
"""

import sys
import os
import json

from django.views.decorators.csrf import csrf_exempt

from django.http import JsonResponse

from django.http import HttpResponse
from django.shortcuts import render

from django.shortcuts import render_to_response
from django.http import HttpResponseRedirect  



#for the file download
from django.http import StreamingHttpResponse

# resolve the html text be filter ,make it excape

sys.path.append(os.path.abspath(os.path.join(__file__, '../../00_Programs')))

from A04_Scoring.search_func import search_reports
from A04_Scoring.sec_word_tree import search_word_tree
from A60_html.generate_html   import generate_html_more

import re

@csrf_exempt
def insure(request):
    print("enter insure index ")
    
    request.encoding='utf-8'           


    
    '''
    fname='out_master_securities.csv'
  
    #print ("your abs  path:"+ os.path.abspath('.'))
    #the_file_name = str(fname).split("/")[-1]  
    filename = './static/csv/{}'.format(fname)  
    print("file name:",filename)    
    
    df_html = pd.read_csv(filename)
    
    #generate the options 
    options = ""

    
    for idx, row in df_html.iterrows():
    
        for i, p in enumerate(row):
            
            st = str(p)
    
            if i == 0:
                line = "<option value=\"" + st code+"\">"+yourword "</option>"
                       <option value="999"></option>

    
        options += line
   
    '''
    


    try: 
        return render_to_response('insure.html')
    except:
        print("Exception in insure ")
        return HttpResponse("We are sorry , no matching data be found ")

@csrf_exempt
def insure2(request):
    print("enter insure2 ")
    if request.method == "GET": 
        try:    
            ck1=''

            
            request.encoding='utf-8'           
            ck1 = request.GET['ck1']
            codeid = request.GET['code']
            sec_name = request.GET['sec_name']
            #ainame = request.POST.getlist('ainame')

            print("enter insure2 ,got :",ck1+codeid)
            
            #next page
            nextpp={}
            newlines=""
           
            df1=None
            if (ck1.strip()=="") and (codeid.strip()==""):
                print("insure2 checkbox info, no parameters got .")
                return ""
            else:
                print("enter now ,got :",ck1+codeid)
                #df1= search_reports(sec_code = str(codeid), sbase = str(ck1))
                
        
                df1 = search_reports(sec_code = str(codeid), sbase = str(ck1))
        
            
            newlines= pdataframe(df1)
            
            #print(str(newlines))
            
          
            #return render(request,"reports.html",nextpp)
            
            return render_to_response('insure2.html',{'nextpp':nextpp,'lines':newlines,'ck1':ck1,'sec_name':sec_name})
            #return render(request,"reports.html",nextpp)
        except:
            print("Exception in reports show ")
            return HttpResponse(" No matching data ")
    else:
            
        print("null , there is no such request method ")
        return HttpResponse("no such method or data found ")

    


#insure, already a method here    
#insure1, no such name 
#insure2, already a method here
#insure3 perhaps need double check,merged future with insure2
#insure4, already a method here
#insure5 included in the analysis GOT method processing    
#insure6 included in the reportsshow,  reports.html

@csrf_exempt
def word(request):
    ##return render_to_response('c_tree.html')
    return render(request,"c_tree.html",locals())


@csrf_exempt
def words(request):

    try:    
        return render(request,"cycle_tree.html",locals())
    except:
        return HttpResponse(" No matching data ")

     

            

@csrf_exempt
def ajax_dict(request):
    print("enter ajax_dict")
    if request.method == 'POST':
        try:     
            request.encoding='utf-8'
            ppword=""
            print("enter ajax post")
           
            # 0, according to json.stringfy() , use below method to recieve parameter
            json_receive = json.loads(request.body)
    
            ppword = json_receive['pword']
            print("keyword post :",ppword)
   
            rdo='1'
    
            # 1,
        
            result = {}
            result['success'] = True

            json.dumps(result)
    
            
            # 2， give new dataset with json, 
            #next page
            nextpp=""

            #execute client main request 
            nextpp = dict.testword(rdo,ppword)
            print("ajax search result/next page :",nextpp) 
            #3
            
            if nextpp.strip()==None:
                print("We are sorry , there is no such relevant data or matching ")
                
            elif nextpp.strip()=="":
    
                print("We are sorry , there is no such relevant data or matching ")
                return HttpResponse("We are sorry , there is no such matching data found ")
            else:        
                #  3,  show the result page
                print("READY DILIVER?")
                
                #'cycle_tree.html'
                #return render_to_response(nextpp,{})
                
                            
                '''
                return render(request,"wordj.html",
                                {
                                    "name":name,
                                    "i":i,
                                    "l":l,
                                    "d":d,  #键对应的是模板里的名字。值对应的是上面定义的变量
                                    "person_egon":person_egon,
                                    "person_dada":person_dada,
                                    "person_list":person_list,
                                }
                          )
            
                '''
                        
       
                return HttpResponseRedirect('words')
        except:
            print("Exception in ajax_dict  ")

            return HttpResponse("No matching words be found in dictionary ")
           
        
#################################

@csrf_exempt
def analysis(request): 
    request.encoding='utf-8'
    #get method 
    if request.method == "GET":
        try: 
            
       
            
            codeid=""
            codeid = request.GET['cde']
            ck1 = request.GET['ck1']
            print("analysis ,tree json before input code :",str(codeid)+ck1)
            #cwd = os.getcwd()
            #cwd=cwd+'/templates/__'+codeid+'.html'
            
            #print(cwd)
            #next page
            nextpp=""
    
            if (codeid =="") or (codeid== None):
                return HttpResponse(" Need one index code ")
            
            '''   
            else:
                if os.path.exists(cwd):
                    return render(request,"__"+codeid+".html",locals())
                else:
                    pass
            '''
            #print(cwd)
        
            #execute client main request 
    #        sec, sec_name, relations_prob, max_refer_prob, min_refer_prob, saved_dir, threshold = search_word_tree(sec_code = str(codeid))
            word_tree = search_word_tree(sec_code = str(codeid))
            if word_tree is None:
                nextpp =""
                sec_name =""
            else:
                sec, sec_name, relations_prob, max_refer_prob, min_refer_prob, saved_dir, threshold = word_tree[0],\
                                                                                                      word_tree[1],\
                                                                                                      word_tree[2],\
                                                                                                      word_tree[3],\
                                                                                                      word_tree[4],\
                                                                                                      word_tree[5],\
                                                                                                      word_tree[6]
                
              
                nextpp,sec_name= generate_html_more(sec, sec_name, relations_prob, max_refer_prob, min_refer_prob, saved_dir, threshold,None,None)
            #######################waiting for open test it #####################################################################nextpp = dict.testword(rdo,ppword)
            print("analysis GET Method search result/next page :",nextpp) 
            
    
            if nextpp.strip() == None or nextpp.strip() == "":
    
                return HttpResponse("none, there is no such matching data found ")
            else:        
                #  3,  show the result page
                print("READY DILIVER?")
                print("nextpage?",nextpp)
                
    
                return render_to_response(nextpp,{'sec_name':sec_name})
        
            
        except:
            print("Exception in analysis GOT method  ")
            
            return HttpResponse(" No matching data ")
        

    
    #post method is early requirement,
    if request.method == "POST":
        ppword=""
        ppword = request.POST.get('stockid')
        print("customer input word :",str(ppword))

        rdo='1'
        
        #next page
        nextpp=""

        try:  
           
            #execute client main request 
            nextpp = dict.testword(rdo,ppword)
            print("analysis POST method search result/next page :",nextpp) 

            if nextpp.strip()==None or nextpp.strip()=="":
              
                return HttpResponse(" No matching data ")

            else:        
                #  3,  show the result page
                print("READY DILIVER?")

                return HttpResponseRedirect('words')

        except:
            print("Exception in ajax_dict  ")

            return HttpResponse("No matching words ")


        
#################################
 

@csrf_exempt
def reportshow(request):
    if request.method == "GET": 
        try: 
            ck1=''
            request.encoding='utf-8'           
            words = request.GET['wd']
            #ainame = request.POST.getlist('ainame')
            codeid = request.GET['cde']
            sec_name = request.GET['sec_name']
         
            print("enter report show ,got :",words+codeid+sec_name)
            
            #next page
            nextpp={}
            df1=None
            
            if (codeid.strip()==""):
                print("report show , no parameters got .")
                return ""
            else:

                df1= search_reports(sec_code = str(codeid), feature_word =words)

            newlines= pdataframeR(df1)

            if newlines ==None:
                print("none , there is no such relevant data or matching ")
                return HttpResponse("none, there is no such matching data found ")
            elif newlines =="":
        
                print("null , there is no such relevant data or matching ")
                return HttpResponse("null , there is no such matching data found ")
        
            else: 
                return render_to_response('reports.html',{'nextpp':nextpp,'lines':newlines,'words':words,'codeid':codeid,'ck1':'pn','sec_name':sec_name})  
        except:
            print("Exception in reports show ")
            return HttpResponse("We are sorry , no matching data be found ")
    else:
        
        print(" there is no such request method ")
        return HttpResponse("no such method or data found ")


#################################

def convert_html_link(col_data):
    cwd = os.getcwd()
    f_url = lambda x : os.path.abspath(os.path.join(cwd, x)).replace('\\', '/')
    return col_data.apply(f_url)


@csrf_exempt
def staticfile(request):
    print("enter staticfile")
    
    request.encoding='utf-8'           
    filename = request.GET['fn']
    #ainame = request.POST.getlist('ainame')
    #codeid = request.GET['cde']
    filename = str(filename).split("/")[-1]  
    filename1 = './web/templates/{}'.format(filename)  
    print("enter static file show,got :",filename1)

    if os.path.isfile(filename1):
        return render(request,filename1,locals())
    else:
        return HttpResponse("static file , there is no such file")
   


### do the pandas dataframe to django template loop data ###########################
def pdataframe(df_html1):

    #col_n = ['report_id', 'sec_code', 'sec_name','broker_name', 'report_date','summary', 'センチメントスコア（ベクトルベース）', 'センチメントスコア（極性値ベース）','センチメントスコア（参考値）', 'レコメンデーションスコア', 'レコメンデーションスコア（参考値）']
    try:
        df_html1 = df_html1.where(df_html1.notnull(),"")
        df_htmllink = convert_html_link(df_html1["pdf_path"])
        
        df_html = df_html1.drop(columns = ['pdf_path'])
        
        lines = ""
        j = 0 
        
        for idx, row in df_html.iterrows():
        
            for i, p in enumerate(row):
        
                if  (p != None):
                    st =  str(p)              
        
                else:
                    st = str("")
                #just for the .0    
                if (i>len(row)-6):
                   if st!="":
                       #filter the  non-number and blank 
                       #st= re.sub("\D", "", st) 
                       
                       st=re.sub(r'\.[0-9]+','',st,1,flags=re.I)
    
                   else:
                       pass
                    #st=st.split(".")[-2]  
                if i == 0:
                    
                    #(filepath,linkstr) = os.path.split((df_htmllink[j][2:]))
                    #filepath=os.path.dirname(df_htmllink[j]) ,remove the '..'
                    line = "<TR><TD style=\"text-align: left;\"><a href=\"../fdownload?fn="+(df_htmllink[j])+"\">"  + st + "</a></TD>"
                elif i==len(row)-6 :
                
                    line += "<TD width =20%><div id=\"tdspecial\" style=\"text-align: left;\"><span>" + st + "</span></div></TD>"
                elif i == len(row) - 1:
                    
                    #print(str(math.floor(float(st))))
                    line += "<TD>" + st + "</TD></TR>\n"
        
                else:
                    line += "<TD>" + st + "</TD>"
        
            lines += line
            j += 1     
    except:
        lines=""
        #print("before to page",lines)
    
    return lines
    

###With radio content, do the pandas dataframe to django template loop data ###########################
def pdataframeR(df_html1):

    ###test ok,open. ###df_html = pd.read_csv('C:/JINSHUXIN/Milize_AI/Milize_AI/test.csv')
    print("enter into dataframe R, ")
    try:
        df_html1 = df_html1.where(df_html1.notnull(),"")
    
       
        #col_n = ['report_id', 'sec_code', 'sec_name','broker_name', 'report_date','summary', 'センチメントスコア（ベクトルベース）', 'センチメントスコア（極性値ベース）','センチメントスコア（参考値）', 'レコメンデーションスコア', 'レコメンデーションスコア（参考値）']
    
        df_htmllink = convert_html_link(df_html1["pdf_path"])
        
        df_html = df_html1.drop(columns = ['pdf_path','word','freq'])
        #filter the nan field
        df_html = df_html.where(df_html.notnull(),"")
    
        
        lines = ""
        j = 0 
        k = 1
        for idx, row in df_html.iterrows():
        
            for i, p in enumerate(row):
          
                if (p != None):
                    st =  str(p) 
                else:
                    st = str(p)
                    #for the .0
                if (i>len(row)-4):
                    if st!="":
                       
                       #st= re.sub("\D", "", st) 
                       #st=st[:-2]
                       st=re.sub(r'\.[0-9]+','',st,1,flags=re.I)
                    else:
                       pass
                    
                if (i==len(row)-5):
                    st=re.sub(r'\.[0-9]+','',st,1,flags=re.I)
                if i == 0:
                    
                    #(filepath,linkstr) = os.path.split((df_htmllink[j][2:]))
                    #filepath=os.path.dirname(df_htmllink[j])
                    line = "<TR><TD style=\"text-align: left;\"><a href=\"../fdownload?fn="+(df_htmllink[j])+"\">"  + st + "</a></TD>"
        
                elif i == len(row) - 1:
                    line += "<TD>" + st + "</TD>"
                    #Radio group here
                    line+= "<TD style=\"font-size:9px;\">" + gen_radio_str(k) + "</TD>"
                    line+= "<TD style=\"font-size:9px;\">" + gen_radio_stra(k) + "</TD>"  +"</TR>\n"
        
                elif i==len(row)-6 :
                
                    line += "<TD><div id=\"tdspecial\" style=\"text-align: left;\"><span>" + st + "</span></div></TD>"
                else:
                    line += "<TD>" + st + "</TD>"
    
            k=k+1
            lines += line
            j += 1     
    #print(lines)
    except:
        lines=""
    return lines   


def gen_radio_str(i):
    radiostr=""
    radiostr =  "<input type=\"radio\" id=\"ck2\" class=\"radio\" name=\"rd"+ str(i) +"\"  \/><label>100</label>&nbsp;"
    radiostr += "<input type=\"radio\" id=\"ck2\" class=\"radio\" name=\"rd"+ str(i) +"\" \/><label>75 </label>&nbsp;"
    radiostr += "<input type=\"radio\" id=\"ck2\" class=\"radio\" checked name=\"rd"+ str(i) +"\" \/><label>50 </label>&nbsp;"
    radiostr += "<input type=\"radio\" id=\"ck2\" class=\"radio\" name=\"rd"+ str(i) +"\" \/><label>25 </label>&nbsp;"
    radiostr += "<input type=\"radio\" id=\"ck2\" class=\"radio\" name=\"rd"+ str(i) +"\" \/><label>0  </label>&nbsp;"
         
    return radiostr

def gen_radio_stra(i):
    radiostr=""
    radiostr =  "<input type=\"radio\" id=\"ck3\" class=\"radio\" name=\"rd"+ str(i) +"j" +"\" \/><label>100</label>&nbsp;"
    radiostr += "<input type=\"radio\" id=\"ck3\" class=\"radio\" name=\"rd"+ str(i) +"j" +"\" \/><label>75 </label>&nbsp;"
    radiostr += "<input type=\"radio\" id=\"ck3\" class=\"radio\" checked name=\"rd"+ str(i)+"j" +"\" \/><label>50 </label>&nbsp;"
    radiostr += "<input type=\"radio\" id=\"ck3\" class=\"radio\" name=\"rd"+ str(i)+"j"  +"\" \/><label>25 </label>&nbsp;"
    radiostr += "<input type=\"radio\" id=\"ck3\" class=\"radio\" name=\"rd"+ str(i)+"j"  +"\" \/><label>0  </label>&nbsp;"
         
    return radiostr
    
#import os

def fdownload(request):
    if request.method == "GET":
        request.encoding='utf-8'           
        download_name = request.GET['fn']
        print("download,file name:",download_name)
        #print ("your abs  path:"+ os.path.abspath('.'))
        the_file_name = os.path.basename(download_name)
        filename = download_name
        print("download,abs file name:",os.path.abspath(filename))
        response = StreamingHttpResponse(readFile(filename))
        response['Content-Type'] = 'application/octet-stream'
        response['Content-Disposition'] = 'attachment;filename="{0}"'.format(the_file_name)
        return response


def readFile(filename, chunk_size=512):
    """
    :param filename:
    :param chunk_size:
    :return:
    """
    try:
        with open(filename, 'rb') as f:
            while True:
                c = f.read(chunk_size)
                if c:
                    yield c
                else:
                    break    
    except:
        print("no such file here, "+filename)
        return HttpResponse("download ,no such file here ") 
    
    




