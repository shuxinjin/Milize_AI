# -*- coding: utf-8 -*-
'''
Name        : output_securities_report.py
Purpose     : 特定の銘柄を対象としたレポート出力
Created Date: 2018.9.3
Created by  : Wenfeng Huang (MILIZE Inc.)
Updated Date: 2018.9.3
Updated by  : Wenfeng Huang (MILIZE Inc.)
'''

import sys
sys.path.append('./A04_Scoring')
sys.path.append('./A90_utils')

from A04_Scoring.word_level_analyzer import word_level_analyzer
import A60_html.generate_html as generate_html

#add by jin, for the create flag ,global,0 mean 

yourdata1=[False,None] 
def getyourdata(ydata):
    global yourdata1 
    yourdata1 = ydata 

##########################



####add by jin
def testword(rdo,keyw):
      
        print("input/enter main AI  with :",keyw)
        if  ((keyw==None) or (keyw=="")):
            return ""
        else:
            #redo search from the web request
     
            generate_html.getyourdata1([int(rdo),keyw])   
            ####w.searchw=kewy
            if yourdata1[0]:
               
                sss= yourdata1[1].get_surroundings(keyw.strip())
#                print("existed class ,return what:",sss)
                return sss
            else:
                       
                w = word_level_analyzer()
                
                
                w.main(create_flg = False)
            
                getyourdata([True,w])
               
                sss= yourdata1[1].get_surroundings(keyw.strip()) 
                print("new create class:return what:",sss) 
                return sss
        
        generate_html.getyourdata1([0,''])   
    ####################   



if __name__ == '__main__':
    with word_level_analyzer() as w:
        w.main(quarter_flg = True, create_flg = False)
#
#    testword('1','c上c')
    testword('1', '前提') 
#    with word_level_analyzer() as w:
#        w.main(create_flg = False)
