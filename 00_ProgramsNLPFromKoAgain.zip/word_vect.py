# -*- coding: utf-8 -*-
'''
Name        : output_securities_report.py
Purpose     : 特定の銘柄を対象としたレポート出力
Created Date: 2018.9.3
Created by  : Wenfeng Huang (MILIZE Inc.)
Updated Date: 2018.9.3
Updated by  : Wenfeng Huang (MILIZE Inc.)
'''

import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), './A04_Scoring'))
sys.path.append(os.path.join(os.path.dirname(__file__), './A50_Config'))
sys.path.append(os.path.join(os.path.dirname(__file__), './A90_utils'))

from A04_Scoring.word_level_analyzer import word_level_analyzer

if __name__ == '__main__':
    
    with word_level_analyzer() as w:
        w.main(quarter_flg = False, create_flg = False)
        
