#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Friday Aug 21 18:38:58 2020

@author: shuxin.jin@hotmail.com
"""
# to detect the os path
import os
# specify the directory where the model files are stored
#BERT_BASE_DIR = '/path/to/mecab-ipadic-bpe-32k/do-whole-word-mask'
#download the pre-trained model, https://github.com/singletongue/japanese-bert/releases
#BERT_BASE_DIR = '/base_dir/mecab-ipadic-bpe-4k/BERT-base_mecab-ipadic-char-4k_do-whole-word-mask'
BERT_BASE_DIR = '\\japanese_bert_1_0\\base_dir\\mecab-ipadic-bpe-32k\\BERT-base_mecab-ipadic-bpe-32k_do-whole-word-mask'
import torch

#This model is a PyTorch torch.nn.Module sub-class. Use it as a regular PyTorch Module and refer to the PyTorch documentation for all matter related to general usage and behavior.
from transformers import BertForMaskedLM
#need to install, pip install tokenization
from tokenization import MecabBertTokenizer, MecabCharacterBertTokenizer
#get current os path
curPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(curPath)[0]
#modified again,by jin,20200825
BERT_BASE_DIR= rootPath+BERT_BASE_DIR  

#load pre-train model
model = BertForMaskedLM.from_pretrained(BERT_BASE_DIR)
#load mecab tokenizer
model.output_hidden_states = False #APPEND TEMPRARY JIN
#if error raised ,please uninstall transformers, and re-install version 2.8.0 it  2.7.0, 2.8.0, 2.9.0, 2.9.1, 2.10.0, 2.11.0, 3.0.0, 3.0.1, 3.0.2)
#currently , only transformers version 2.8.0 worked on this ,comments by jin 20200828
tokenizer = MecabBertTokenizer(vocab_file=f'{BERT_BASE_DIR}/vocab.txt')
# Use MecabCharacterBertTokenizer instead for char-4k models

text = '朝食に[MASK]を焼いて食べました。'

token_ids = tokenizer.encode(text, add_special_tokens=True)

tokens = tokenizer.convert_ids_to_tokens(token_ids)

token_ids = torch.tensor([token_ids])

predictions, = model(token_ids)
_, top10_pred_ids = torch.topk(predictions, k=10, dim=2)

for correct_id, pred_ids in zip(token_ids[0], top10_pred_ids[0]):
    correct_token = tokenizer.convert_ids_to_tokens([correct_id.item()])
    pred_tokens = tokenizer.convert_ids_to_tokens(pred_ids.tolist())
    print(correct_token, pred_tokens)
    

